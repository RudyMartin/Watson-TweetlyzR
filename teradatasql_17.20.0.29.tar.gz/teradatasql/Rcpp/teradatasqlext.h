// Copyright 2022 by Teradata Corporation. All Rights Reserved.
// TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#include <Rcpp.h>
#include <string.h>

#if defined(_WIN64)
/* Windows --> */

#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

#else
/* Apple and Linux --> */

#include <pthread.h>
#include <sys/time.h>

#endif

struct log_ {
	bool bTraceLog ;
	bool bDebugLog ;
	bool bTimingLog ;
	bool bDeserializeOne ;
} ;

#if defined(_WIN64)
#define __getCurrentThreadId  (GetCurrentThreadId)()
#else
#define __getCurrentThreadId (pthread_self)()
#endif

typedef unsigned long uint32 ;
typedef unsigned long long  uint64 ;
typedef long int32 ;
typedef long long  int64 ;
