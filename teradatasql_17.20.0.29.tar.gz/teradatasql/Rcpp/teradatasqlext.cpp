// Copyright 2022 by Teradata Corporation. All Rights Reserved.
// TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#include <bitset>
#include <math.h>
#include <Rcpp.h>
#include <string.h>
#include <teradatasqlext.h>

using namespace Rcpp ;

// Force compilation mode to C++11
// [[Rcpp::plugins(cpp11)]]

int littleEndianHost (void) {

	int num = 42 ;

	if (*(char *) & num == 42) { return (1) ; }
	return (0) ;

} // end littleEndianHost

int getMillisecondsOfCurrentTime()
{
	int ms = 0;

#if defined(_WIN64)
	SYSTEMTIME lt;

	GetLocalTime(&lt);
	ms = lt.wMilliseconds;

#else
	struct timeval time_now;

	gettimeofday(&time_now, NULL); // get milliseconds
	ms = (int) time_now.tv_usec / 1000;
#endif

	return ms;

} // end getMillisecondsOfCurrentTime

void logMsg (const char* category, const char* s) {
	time_t t = time(NULL) ;
	struct tm tm = *localtime(&t) ;
	int milliseconds = getMillisecondsOfCurrentTime () ;
	unsigned long tid = (unsigned long) __getCurrentThreadId ;

	Rprintf ("%d-%02d-%02d %02d:%02d:%02d:%03i [tid %lu] RDBIEXT-%s teradatasqlext.cpp %s"
		, tm.tm_year + 1900
		, tm.tm_mon + 1
		, tm.tm_mday
		, tm.tm_hour
		, tm.tm_min
		, tm.tm_sec
		, milliseconds
		, tid
		, category
		, s) ;

	fflush(stdout) ;
} // end logMsg

void traceLog (const char* s) {
	logMsg ("TRACE", s) ;
}

void debugLog  (const char* s) {
	logMsg ("DEBUG", s) ;
}

void setLoggingLevel (struct log_ *log, int64 nLog) {

	if ((nLog & 1) != 0) {
		log->bTraceLog = true;
	} else {
		log->bTraceLog = false;
	}
	if ((nLog & 2) != 0) {
		log->bDebugLog = true;
	} else {
		log->bDebugLog = false;
	}
	if ((nLog & 8) != 0) {
		log->bTimingLog = true;
	} else {
		log->bTimingLog = false;
	}
	if ((nLog & 32) != 0) {
		log->bDeserializeOne = true;
	} else {
		log->bDeserializeOne = false;
	}
} // end setLoggingLevel

int64 _rawToUnsignedInt64 (RawVector r) {
	unsigned char *ps = RAW (r) ;
	return (*(uint64*)ps) ;
}

int64 _rawToInt64 (RawVector r) {
	unsigned char *ps = RAW (r) ;
	return (*(int64*)ps) ;
}

RawVector _int64ToRaw (int64 i) {
	RawVector r = RawVector (sizeof (int64)) ;
	memcpy (&(r[0]), &i, sizeof (int64)) ;
	return (r) ;
}

std::string _charToBinary (unsigned char* str, int nLen ) {
	constexpr int n = 80 ; // Limit to 80 bytes
	std::bitset<CHAR_BIT * n> bits(*str) ;
	return bits.to_string () ;
}

void serializeString (StringVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (aoColVector [nRowIndex] == NA_STRING) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	//Add 2 for 'ZZ' at end of buffer or next column data type
	int64 nByteLength = aoColVector [nRowIndex].size () ;
	if (*nBufIndex + nByteLength + (int64) sizeof (int64) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeString() while proccessing row %lld. The amount of data %lld exceeds the buffer size of %lld.\n", nRowIndex + 1, *nBufIndex + nByteLength + sizeof (int64) + 2, nBufferSize) ;
		throw exception (sMsg) ;
	}
	memcpy (&(r [*nBufIndex]), &nByteLength,  sizeof (int64)) ;
	*nBufIndex += sizeof (int64) ;

	std::copy (aoColVector [nRowIndex].begin (), aoColVector [nRowIndex].end (), & (r [*nBufIndex])) ;
	*nBufIndex += nByteLength ;

	return ;

}  // end serializeString

void serializeDiffTime (NumericVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (NumericVector::is_na (aoColVector [nRowIndex])) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	double adSeconds = aoColVector [nRowIndex] ;

	const char * asSign   = (adSeconds < 0) ? "-" : " " ;
	adSeconds     = std::abs (adSeconds) ;

	int adMinutes = adSeconds / 60 ;
	int adHours   = adMinutes / 60 ;
	int adDays    = adHours   / 24 ;

	adHours   = adHours   % 24 ;
	adMinutes = adMinutes % 60 ;
	adSeconds = std::fmod (adSeconds, (double) 60) ;

	char sDiffTime [45] ;

	sprintf (sDiffTime, "%s%d %02d:%02d:%09.6f", asSign, adDays, adHours, adMinutes, adSeconds) ;

	int64 nByteLength = strlen (sDiffTime) ;
	//Add 2 for 'ZZ' at end of buffer or next column data type
	if (*nBufIndex + nByteLength + (int64) sizeof (int64) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeDiffTime() while proccessing row %lld. The amount of data %lld exceeds the buffer size %lld.\n", nRowIndex + 1, *nBufIndex + nByteLength + sizeof (int64) + 2, nBufferSize) ;
		throw exception (sMsg) ;
	}

	memcpy (&(r [*nBufIndex]), &nByteLength,  sizeof (int64)) ;
	*nBufIndex += sizeof (int64) ;

	memcpy (&(r [*nBufIndex]), sDiffTime,  nByteLength) ;
	*nBufIndex += nByteLength ;

} // end serializeDiffTime

void serializeDouble (NumericVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (NumericVector::is_na (aoColVector [nRowIndex]) && ! traits::is_nan <REALSXP>(aoColVector [nRowIndex])) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	//Add 2 for 'ZZ' at end of buffer or next column data type
	if (*nBufIndex + (int64) sizeof (int64) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeDouble() while proccessing row %lld. The amount of data %lld exceeds the buffer size %lld.\n", nRowIndex + 1, *nBufIndex + sizeof (int64) + 2, nBufferSize) ;
		throw exception (sMsg) ;
	}

	memcpy (&(r [*nBufIndex]), & (aoColVector [nRowIndex]), sizeof (int64)) ;
	*nBufIndex += sizeof (int64) ;

} // end serializeDouble

void serializeInt (IntegerVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (IntegerVector::is_na (aoColVector [nRowIndex])) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	// Add 2 for 'ZZ' at the end of buffer or next column data type
	if (*nBufIndex + (int64) sizeof (int) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeInt() while proccessing row %lld. The amount of data %lld exceeds the buffer size %lld.\n", nRowIndex + 1, *nBufIndex + sizeof (int) + 2, nBufferSize) ;
		throw exception (sMsg) ;
	}

	memcpy (&(r [*nBufIndex]), & (aoColVector [nRowIndex]), sizeof (int)) ;
	*nBufIndex += sizeof (int) ;

} // end serializeInt

void serializeDate (DateVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (DateVector::is_na (aoColVector (nRowIndex))) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	Date d = aoColVector (nRowIndex) ;
	std::string sDate = d.format () ; // default is "YYYY-MM-DD"

	int64 nByteLength = sDate.length () ;
	//Add 2 for 'ZZ' at end of buffer or next column data type
	if (*nBufIndex + nByteLength + (int64) sizeof (int64) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeDate() while proccessing row %lld. The amount of data %lld exceeds the buffer size %lld.\n", nRowIndex + 1, *nBufIndex + nByteLength + sizeof (int64) + 2, nBufferSize) ;
		throw exception (sMsg) ;
	}
	memcpy (&(r [*nBufIndex]), &nByteLength,  sizeof (int64)) ;
	*nBufIndex += sizeof (int64) ;

	memcpy (&(r [*nBufIndex]), sDate.c_str (), nByteLength) ;
	*nBufIndex += nByteLength ;

} // end serializeDate

void serializeBytes (GenericVector aoColVector, RawVector r, int64 *nBufIndex, char charColType, int64 nRowIndex, int64 nBufferSize) {

	if (TYPEOF (aoColVector [nRowIndex]) == LGLSXP) {
		charColType = 'N' ;
		memcpy (&(r [*nBufIndex]), &charColType, 1) ;
		(*nBufIndex)++ ;
		return ;
	}

	// Copy column type
	memcpy (&(r [*nBufIndex]), &charColType, 1) ;
	(*nBufIndex)++ ;

	//Add 2 for 'ZZ' at end of buffer or next column data type
	int64 nByteLength = as<RawVector> (aoColVector [nRowIndex]).size () ;
	if (*nBufIndex + nByteLength + (int64) sizeof (int64) + 2 > nBufferSize) {
		char sMsg [200] ;
		sprintf (sMsg, "An error occurred in serializeBytes() while proccessing row %lld. The amount of data %lld exceeds the buffer size %lld.\n", nRowIndex + 1, *nBufIndex + nByteLength + sizeof (int64) + 2, nBufferSize) ;
		throw exception  (sMsg) ;
	}
	memcpy (&(r [*nBufIndex]), &nByteLength,  sizeof (int64)) ;
	*nBufIndex += sizeof (int64) ;

	// Copy byte value
	memcpy (&(r [*nBufIndex]), as<RawVector>(aoColVector [nRowIndex]).begin (), nByteLength) ;
	*nBufIndex += nByteLength ;

} // end serializeBytes

// [[Rcpp::export]]
RawVector serializeRowsRcpp (RawVector rawLog, RawVector rawMaxBufSize, IntegerVector anColumnType, GenericVector aaoRows) {

	char sMsg [1024] = "" ;
	struct log_ log ;
	int64 nLog  = _rawToInt64 (rawLog) ;
	setLoggingLevel (&log, nLog) ;

	if (! littleEndianHost ()) {

		sprintf (sMsg, "serializeRowsRcpp: Error Unsupported big-endian host") ;

		if (log.bDebugLog) {
			debugLog (sMsg) ;
		}

		throw exception (sMsg) ;
	}

	int64 nBufferSize  = _rawToInt64 (rawMaxBufSize) ;
	int64 nRowCount = as <GenericVector> (aaoRows [0]).size () ;
	int nColCount = aaoRows.size () ;

	if (log.bTraceLog) {
		sprintf (sMsg, "> enter serializeRowsRcpp nRows=%lld, nCols=%d, nBufferSize=%lld\n", nRowCount, nColCount, nBufferSize) ;
		traceLog (sMsg) ;
	}

	if (nRowCount == 0) {
		if (log.bDebugLog) {
			debugLog ("serializeRowsRcpp can't continue row count is 0\n") ;
		}
		return RawVector (0) ;
	}

	if (nColCount == 0) {
		if (log.bDebugLog) {
			debugLog ("serializeRowsRcpp can't continue column count is 0\n") ;
		}
		return RawVector (0) ;
	}

	RawVector r (nBufferSize) ;
	int64 nBufIndex = 0 ;
	char chTerminator = 'Z' ;

	for  (int64 nRowIndex = 0 ; nRowIndex < nRowCount ; nRowIndex++) {

		Rcpp::checkUserInterrupt () ;

		for (int nColIndex = 0 ; nColIndex < nColCount ; nColIndex++) {

			int nColumnType = anColumnType [nColIndex] ;

			if (log.bDebugLog) {
				sprintf (sMsg, "serializeRowsRcpp processing row=%lld, column=%d, type=%d, nBufIndex=%lld\n", nRowIndex + 1, nColIndex + 1,  nColumnType, nBufIndex) ;
				debugLog (sMsg) ;
			}

			switch (nColumnType) {

				case  1: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'L', nRowIndex, nBufferSize) ; break ;    // int64
				case  2: serializeDate     (aaoRows [nColIndex], r, &nBufIndex, 'U', nRowIndex, nBufferSize) ; break ;    // Date
				case  3: serializeInt      (aaoRows [nColIndex], r, &nBufIndex, 'I', nRowIndex, nBufferSize) ; break ;    // Integer
				case  4: serializeDouble   (aaoRows [nColIndex], r, &nBufIndex, 'D', nRowIndex, nBufferSize) ; break ;    // Double
				case  5: serializeBytes    (aaoRows [nColIndex], r, &nBufIndex, 'B', nRowIndex, nBufferSize) ; break ;    // binary (raw)
				case  6: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'V', nRowIndex, nBufferSize) ; break ;    // hms
				case  7: serializeDiffTime (aaoRows [nColIndex], r, &nBufIndex, 'S', nRowIndex, nBufferSize) ; break ;    // difftime
				case  8: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'W', nRowIndex, nBufferSize) ; break ;    // TimeWithTimeZone
				case  9: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'X', nRowIndex, nBufferSize) ; break ;    // Timestamp
				case 10: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'Y', nRowIndex, nBufferSize) ; break ;    // TimestampWithTimeZone
				case 11: serializeString   (aaoRows [nColIndex], r, &nBufIndex, 'S', nRowIndex, nBufferSize) ; break ;    // String
				default:
					sprintf (sMsg, "Error in serializeRowsRcpp: unrecognized column type %d for row %lld, column %d", nColumnType, nRowIndex + 1, nColIndex + 1) ;

					if (log.bDebugLog) {
						debugLog (sMsg) ;
					}
					throw std::range_error (sMsg) ;

			} // end switch

		} // end for loop for columns

		memcpy (&(r [nBufIndex]), &chTerminator, sizeof (char)) ;
		nBufIndex ++ ;

	} // end for loop for rows

	memcpy (&(r [nBufIndex]), &chTerminator, sizeof (char)) ;
	nBufIndex ++ ;

	if (nBufIndex == nBufferSize) return r ;
	if (nBufIndex > nBufferSize) {

		sprintf (sMsg, "Memory error in serializeRowsRcpp: Memory allocated %lld but needed memory %lld", nBufferSize, nBufIndex ) ;

		if (log.bDebugLog) {
			debugLog (sMsg) ;
		}

		throw exception (sMsg) ;
	}

	return r [Range (0, (R_xlen_t) (nBufIndex - 1))] ;

} // end serializeRowsRcpp

// [[Rcpp::export]]
List deserializeRowsRcpp (RawVector rawLog, RawVector rawRowCount, int nCols, RawVector rw, StringVector sClasses, StringVector sTypes) {

	char sMsg [1024] = "" ;
	struct log_ log ;
	int64 nLog  = _rawToInt64 (rawLog) ;
	setLoggingLevel(&log, nLog) ;

	if (! littleEndianHost ()) {

		sprintf (sMsg, "deserializeRowsRcpp: Error Unsupported big-endian host") ;

		if (log.bDebugLog) {
			debugLog (sMsg) ;
		}

		throw exception (sMsg) ;
	}

	bool bContainsRawValue = false ;
	int64 nRows = (int64) _rawToInt64 (rawRowCount) ;

	if (log.bTraceLog) {
		sprintf (sMsg, "> enter deserializeRowsRcpp nRows=%lld, nCols=%d\n", nRows, nCols) ;
		traceLog (sMsg) ;
	}

	Function setNA = Environment::namespace_env("teradatasql") ["setNA"] ;
	Function rawToList = Environment::namespace_env("teradatasql") ["rawToList"] ;

	unsigned char *bPtr = RAW (rw) ;
	int nRowIndex = 0 ;
	int nColIndex = 0 ;

	GenericVector vColumns = GenericVector (nCols) ;
	if (nRows == 0) {
		if (log.bDebugLog) {
			debugLog ("Warning: deserializeRowsRcpp can't continue rows is 0\n") ;
		}
		return vColumns ;
	}

	unsigned char *ps ;
	for  (ps = bPtr ; *ps != 'Z' /*0x5A - end of Rows*/ ; ps++) {

		Rcpp::checkUserInterrupt () ;
		nRowIndex ++ ;

		for (nColIndex = 0 ; *ps != 'Z' /*0x5A - end of row*/ ; nColIndex++) {

			switch (*ps) {
				case 'I': /* I=integer */
				{

					if (nRowIndex == 1) {
						vColumns [nColIndex] = IntegerVector (nRows) ;
					}

					IntegerVector vRows = vColumns [nColIndex] ;
					ps++ ;

					vRows [nRowIndex - 1] = *(uint32*) ps ;
					ps += 4 ;  // Move past integer

					if (log.bDebugLog) {
						sprintf (sMsg, "deserializeRowsRcpp row[%d] col[%d], typeCode=%c, type=%s, class=%s, value=%d \n", nRowIndex, nColIndex + 1, char (*ps), String (sTypes (nColIndex)).get_cstring (), String (sClasses (nColIndex)).get_cstring (), vRows [nRowIndex - 1]) ;
						debugLog (sMsg) ;
					}

					break;
				} // end case I - Integer

				case 'N': /* N=null */
				{
					ps ++ ; // move past the 'N' (null)

					if (sClasses (nColIndex) == "character"             ||
						sClasses (nColIndex) == "Date"                  ||
						sClasses (nColIndex) == "TimeWithTimeZone"      ||
						sClasses (nColIndex) == "Timestamp"             ||
						sClasses (nColIndex) == "TimestampWithTimeZone" ||
						sClasses (nColIndex) == "POSIXct"               ||
						sClasses (nColIndex) == "hms"                   ||
						sClasses (nColIndex) == "integer64"             ||
						(sClasses (nColIndex) == "numeric" && sTypes (nColIndex) != "FLOAT")) {

						if (nRowIndex == 1) {
							vColumns [nColIndex] = StringVector (nRows) ;
						}

						StringVector vRows = vColumns [nColIndex] ;
						vRows [nRowIndex - 1] = NA_STRING ;
						break ;

					} else if (sClasses (nColIndex) == "integer") {

						if (nRowIndex == 1) {
							vColumns [nColIndex] = IntegerVector (nRows) ;
						}
						IntegerVector vRows = vColumns [nColIndex] ;
						vRows [nRowIndex - 1] = NA_INTEGER ;
						break ;

					} else if (sClasses (nColIndex) == "raw") {

						if (nRowIndex == 1) {
							vColumns [nColIndex] = GenericVector (nRows) ;
						}
						GenericVector vRows = vColumns [nColIndex] ;
						vRows [nRowIndex - 1] = setNA () ;

						break ;

					} else if (sClasses (nColIndex) == "numeric") {

						if (nRowIndex == 1) {
							vColumns [nColIndex] = NumericVector (nRows) ;
						}

						NumericVector vRows = vColumns [nColIndex] ;
						vRows [nRowIndex - 1] = NA_REAL ;
						break ;

					} else {

						const char *sClass = String (sClasses (nColIndex)).get_cstring () ;
						sprintf (sMsg, "Unrecognized null column class '%s' for row %d, column %d", sClass, nRowIndex, nColIndex + 1) ;
						stop (sMsg) ;
					}

					if (log.bDebugLog) {
						sprintf (sMsg, "deserializeRowsRcpp row[%d] col[%d], typeCode=%c, type=%s, class=%s, value=NA\n", nRowIndex, nColIndex + 1, char (*ps), String (sTypes (nColIndex)).get_cstring (), String (sClasses (nColIndex)).get_cstring ()) ;
						debugLog (sMsg) ;
					}

					break ;
				} // end case N - Null

				case 'S': /* S=string */
				case 'U': /* U=date */
				case 'V': /* V=time */
				case 'W': /* W=time with time zone */
				case 'X': /* X=timestamp */
				case 'Y': /* Y=timestamp with time zone */
				case 'M': /* M=numeric */
				case 'L': /* L=long */
				{
					if (nRowIndex == 1) {
						vColumns [nColIndex] = StringVector (nRows) ;
					}

					StringVector vRows = vColumns [nColIndex] ;
					ps ++ ;

					int64 nLen = *(int64*) ps ;
					ps += 8 ;

					if (nLen > 0) {

						char str [nLen + 1] ;
						memcpy (str, ps, nLen) ;
						str [nLen] = 0 ;
						vRows [nRowIndex -1] = str ;
					} else {
						vRows [nRowIndex -1] = "" ;
					}

					ps += nLen ; // move past the string

					if (log.bDebugLog) {
						sprintf (sMsg, "deserializeRowsRcpp row[%d] col[%d], typeCode=%c, type=%s, class=%s, value=%s \n", nRowIndex, nColIndex + 1, char (*ps), String (sTypes (nColIndex)).get_cstring (), String (sClasses (nColIndex)).get_cstring (), String (vRows [nRowIndex - 1]).get_cstring ()) ;
						debugLog (sMsg) ;
					}

					break ;

				} // end case string types (S-string, U-date, V-time, W-time w/ zone, X-timestamp, Y-timestame w/zone, M-numeric, L-long)

				case 'B': /* B=binary */
				{
					bContainsRawValue = true ;
					if (nRowIndex == 1) {
						vColumns [nColIndex] = GenericVector (nRows) ;
					}

					GenericVector vRows = vColumns [nColIndex] ;
					ps ++ ;

					int64 nLen = *(int64*) ps ;
					ps += 8 ;
					RawVector r (nLen) ;

					if (nLen > 0) {
						std::memcpy (r.begin (), ps, nLen) ;
					}
					vRows [nRowIndex - 1] = r ;

					if (log.bDebugLog) {
						sprintf (sMsg, "deserializeRowsRcpp row[%d] col[%d], typeCode=%c, type=%s, class=%s, value=%s ", nRowIndex, nColIndex + 1, char (*ps), String (sTypes (nColIndex)).get_cstring (), String (sClasses (nColIndex)).get_cstring (), _charToBinary (ps, nLen).c_str()) ;
						debugLog (sMsg) ;
					}

					ps += nLen ; // move past binary
					break ;
				} // end case B-binary

				case 'D': /* D=double */
				{

					if (nRowIndex == 1) {
						vColumns [nColIndex] = NumericVector (nRows) ;
					}

					NumericVector vRows = vColumns [nColIndex] ;
					ps ++ ;

					vRows [nRowIndex - 1] = *(double*) ps ;
					ps += 8 ; // Move past double

					if (log.bDebugLog) {
						sprintf (sMsg, "deserializeRowsRcpp row[%d] col[%d], typeCode=%c, type=%s, class=%s, value=%lf \n", nRowIndex, nColIndex + 1, char (*ps), String (sTypes (nColIndex)).get_cstring (), String (sClasses (nColIndex)).get_cstring (), vRows [nRowIndex - 1]) ;
						debugLog (sMsg) ;
					}

					break ;
				} // end case D-date

				default:
					sprintf (sMsg, "Unrecognized column type '%c' for row %d, column %d", *ps, nRowIndex, nColIndex + 1) ;
					stop (sMsg) ;

			} // end switch

		} // end for loop for columns

	} // end for loop for rows

	for (int nCol = 0 ; nCol < nCols ; nCol++ ) {

		if (sClasses (nCol) == "raw" && (nRows > 1 || bContainsRawValue)) {

			if (log.bDebugLog) {
				sprintf (sMsg, "deserializeRowsRcpp converting raw column %d to list by calling external R function\n", nCol + 1) ;
				debugLog (sMsg) ;
			}

			vColumns [nCol] = rawToList (vColumns [nCol]) ;
		}
	}

	if (log.bTraceLog) {
		sprintf (sMsg, "< leave deserializeRowsRcpp nRowIndex=%d, nColIndex=%d\n", nRowIndex, nColIndex) ;
		traceLog (sMsg) ;
	}

	return vColumns ;

} // end deserializeRowsRcpp

// [[Rcpp::export]]
RawVector sumRawLengthRcpp (GenericVector aabyVector) {

	if (Rf_isNull (aabyVector)) return 0 ;
	int64 sum = 0 ;

	for (int i = 0 ; i < aabyVector.length () ; i++) {
		if (TYPEOF (aabyVector [i]) != RAWSXP) { continue ; }
		sum += as<RawVector>(aabyVector[i]).length () ;
	}

	return _int64ToRaw (sum) ;

} // end sumRawLengthRcpp

// sumRawLengthRcpp
RawVector sumRawLengthRcpp (GenericVector aabyVector) ;
RcppExport SEXP sourceCpp_sumRawLengthRcpp(SEXP aabyVectorSEXP) {
BEGIN_RCPP
	Rcpp::RObject rcpp_result_gen;
	Rcpp::RNGScope rcpp_rngScope_gen;
	Rcpp::traits::input_parameter< GenericVector >::type aabyVector (aabyVectorSEXP) ;
	rcpp_result_gen = Rcpp::wrap (sumRawLengthRcpp (aabyVector)) ;
	return rcpp_result_gen ;
END_RCPP
}

// serializeRowsRcpp
RawVector serializeRowsRcpp (RawVector rawLog, RawVector rawMaxSize, IntegerVector anColumnType, GenericVector aaoRows) ;
RcppExport SEXP sourceCpp_serializeRowsRcpp(SEXP rawLogSEXP, SEXP rawMaxSizeSEXP, SEXP anColumnTypeSEXP, SEXP aaoRowsSEXP) {
BEGIN_RCPP
	Rcpp::RObject rcpp_result_gen;
	Rcpp::RNGScope rcpp_rngScope_gen;
	Rcpp::traits::input_parameter< RawVector >::type rawLog (rawLogSEXP) ;
	Rcpp::traits::input_parameter< RawVector >::type rawMaxSize (rawMaxSizeSEXP) ;
	Rcpp::traits::input_parameter< IntegerVector >::type anColumnType (anColumnTypeSEXP) ;
	Rcpp::traits::input_parameter< GenericVector >::type aaoRows (aaoRowsSEXP) ;
	rcpp_result_gen = Rcpp::wrap (serializeRowsRcpp (rawLog, rawMaxSize, anColumnType, aaoRows)) ;
	return rcpp_result_gen ;
END_RCPP
}

// deserializeRowsRcpp
List deserializeRowsRcpp (RawVector rawLog, RawVector rawRowCount, int nCols, RawVector rw, StringVector sClasses, StringVector sTypes) ;
RcppExport SEXP sourceCpp_deserializeRowsRcpp(SEXP rawLogSEXP, SEXP rawRowCountSEXP, SEXP nColsSEXP, SEXP rwSEXP, SEXP sClassesSEXP, SEXP sTypesSEXP) {
BEGIN_RCPP
	Rcpp::RObject rcpp_result_gen;
	Rcpp::RNGScope rcpp_rngScope_gen;
	Rcpp::traits::input_parameter< RawVector >::type rawLog(rawLogSEXP);
	Rcpp::traits::input_parameter< RawVector >::type rawRowCount(rawRowCountSEXP);
	Rcpp::traits::input_parameter< int >::type nCols(nColsSEXP);
	Rcpp::traits::input_parameter< RawVector >::type rw(rwSEXP);
	Rcpp::traits::input_parameter< StringVector >::type sClasses(sClassesSEXP);
	Rcpp::traits::input_parameter< StringVector >::type sTypes(sTypesSEXP);
	rcpp_result_gen = Rcpp::wrap(deserializeRowsRcpp(rawLog, rawRowCount, nCols, rw, sClasses, sTypes)) ;
	return rcpp_result_gen;
END_RCPP
}
