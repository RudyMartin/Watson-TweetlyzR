# Copyright 2018-2019 by Teradata Corporation. All Rights Reserved.
# TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#' TeradataResult class
#'
#' @keywords internal
#' @import bit64
#' @import DBI
#' @import methods
#' @export
#' @rdname TeradataResult-class
setClass ("TeradataResult", contains = "DBIResult", slots = list (
	m_con         = "TeradataConnection",
	m_sOperation  = "character", # used by dbGetStatement
	m_envMutable  = "environment"
))

setMethod ("as.character", "TeradataResult", function (x, ...) {

	return (paste0 ("TeradataResult uConnHandle=", x@m_con@m_uConnHandle, " uRowsHandle=", x@m_envMutable$uRowsHandle, " bCleared=", x@m_envMutable$bCleared))

}) # end method as.character

constructTeradataResult <- function (conn, sOperation) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter TeradataResult ", conn, "\n"))
		on.exit (cat (paste0 ("< leave TeradataResult ", conn, "\n")))
	}

	res <- new ("TeradataResult",
		m_con        = conn,
		m_sOperation = sOperation,
		m_envMutable = new.env (parent = emptyenv ()) # use an environment to hold mutable instance variables
	)

	res@m_envMutable$uRowsHandle <- NA # must initialize because of reference by as.character
	res@m_envMutable$bCleared <- FALSE # must initialize because of reference by as.character

	if (conn@m_bDebugLog) {
		cat (paste0 ("TeradataResult returning ", res, "\n"))
	}

	return (res)

} # end constructTeradataResult

stopIfCleared <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter stopIfCleared ", res, "\n"))
		on.exit (cat (paste0 ("< leave stopIfCleared ", res, "\n")))
	}

	if (res@m_envMutable$bCleared) {
		stop ("TeradataResult is closed")
	}

	invisible (TRUE)

} # end stopIfCleared

integer64ToRaw <- function (n) {

	class (n) <- "numeric"
	return (writeBin (n, raw (), endian = "big"))

} # end integer64ToRaw

integer64ToRawLE <- function (n) {

	class (n) <- "numeric"
	return (writeBin (n, raw (), endian = "little"))

} # end integer64ToRawLE

rawToInteger64LE <- function (aby) {

	d <- readBin (aby, double (), endian = "little")
	class (d) <- "integer64"
	return (d)

} # end rawToInteger64LE

rawToInteger64 <- function (aby) {

	d <- readBin (aby, double (), endian = "big")
	class (d) <- "integer64"
	return (d)

} # end rawToInteger64

# Serialized data value type codes:
# B=bytes
# D=double (64-bit double)
# F=false (bool)
# I=integer (32-bit integer)
# L=long (64-bit integer)
# M=number
# N=null
# S=string (UTF8-encoded)
# T=true (bool)
# U=date
# V=time
# W=time with time zone
# X=timestamp
# Y=timestamp with time zone
# Z=terminator

deserializeCharacterValue <- function (sExpectedTypeCode, aby, i, envByRef) {

	sActualTypeCode <- rawToChar (aby [i])

	if (sActualTypeCode == sExpectedTypeCode) {
		i <- i + 1

		nByteCount <- as.integer (rawToInteger64 (aby [i : (i + 7)]))
		i <- i + 8

		if (nByteCount == 0) {
			sValue <- ""
		} else {
			sValue <- rawToChar (aby [i : (i + nByteCount - 1)])
		}

		i <- i + nByteCount

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- sValue
		}

		return (i)

	} else if (sActualTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type ", sExpectedTypeCode, "/N but got ", sActualTypeCode, " at byte offset ", i))
	}
} # end deserializeCharacterValue

deserializeBool <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode %in% c ("T", "F")) { # T=true, F=false

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- sTypeCode == "T"
		}

		return (i + 1)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type T/F/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeBool

deserializeLong <- function (aby, i, envByRef, convertToDouble = FALSE) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "L") { # L=long
		i <- i + 1

		nValue <- rawToInteger64 (aby [i : (i + 7)])
		i <- i + 8

		if (! is.null (envByRef)) {

			if (convertToDouble) { nValue <- as.numeric (nValue) }

			envByRef$row [[length (envByRef$row) + 1]] <- nValue
		}

		return (i)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type L/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeLong

deserializeNull <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "N") { # N=null

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- NA
		}

		return (i + 1)

	} else {
		stop (paste0 ("Expected column type N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeNull

deserializeString <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("S", aby, i, envByRef))

} # end deserializeString

appendRowToColumnwiseLists <- function (envByRef) {

	for (nColumn in seq_along (envByRef$row)) {

		if (length (envByRef$listColumnwiseLists) < nColumn) {
			envByRef$listColumnwiseLists [[nColumn]] <- list () # construct a list of lists for better append performance
		}

		nRow <- length (envByRef$listColumnwiseLists [[nColumn]]) + 1

		envByRef$listColumnwiseLists [[nColumn]] [[nRow]] <- envByRef$row [[nColumn]] # append each column value to its respective column

	} # end for nColumn

	invisible (TRUE)

} # end appendRowToColumnwiseLists

dataFrameFromColumnwiseLists <- function (listColumnwiseLists, asColumnNames) {

	if (length (listColumnwiseLists) > 0 && length (asColumnNames) != length (listColumnwiseLists)) {
		stop (paste0 ("Column name count ", length (asColumnNames), " differs from column count ", length (listColumnwiseLists)))
	}

	listTemp <- list ()

	for (nColumn in seq_along (listColumnwiseLists)) {

		listColumnValues <- listColumnwiseLists [[nColumn]]

		# raw values are vectors of byte, and we must avoid applying c to raw values, because that will concatenate the values together

		if (isListOfRaw (listColumnValues)) {
			listTemp [[nColumn]] <- I (listColumnValues) # use I to prevent unlisting
		} else {
			listTemp [[nColumn]] <- do.call (c, listColumnValues) # convert list to vector
		}
	} # end for nColumn

	df <- as.data.frame (listTemp, stringsAsFactors = FALSE)

	if (ncol (df) > 0) {
		colnames (df) <- asColumnNames
	}

	return (df)

} # end dataFrameFromColumnwiseLists

obtainRows <- function (res, bPrepare, param) {

	# If underlying values of param do not change, no copy is made. If the values do change copies are made
	# Do not want the application values to change.
	params <- param

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter obtainRows ", res, "\n"))
		on.exit (cat (paste0 ("< leave obtainRows ", res, "\n")))
	}
	tmObtainRowsBegin <- Sys.time ()

	stopIfCleared (res)

	closeRows (res)

	sRequestText <- paste0 (ifelse (bPrepare, "{fn teradata_rpo(S)}", ""), res@m_sOperation)

	if (is.null (params)) {
		params <- data.frame () # convert NULL params to zero-column zero-row data.frame
	}

	if (! is.data.frame (params) && is.list (params)) {
		params <- as.data.frame (params, stringsAsFactors = FALSE) # convert list to data.frame which validates consistent column counts
	}

	if (! is.data.frame (params)) {
		stop (paste0 ("Argument params class ", class (params) [[1]], " differs from the required data.frame or list"))
	}

	if (res@m_con@m_bDebugLog) {
		cat ("obtainRows sRequestText begin:\n")
		cat (paste0 (sRequestText, "\n"))
		cat ("obtainRows params begin:\n")
		print (params)
		cat (paste0 ("obtainRows params ncol=", ncol (params), " nrow=", nrow (params), "\n"))
	}

 	if (nrow (params) && ncol (params)) {

		aaoColumns <- list ()
		for (nColumn in seq_len (ncol (params))) {
			aaoColumns [[length (aaoColumns) + 1]] <- params [, nColumn]
		}

		nMaxSize <- bit64::as.integer64 (0)
		nNumOfRows <- nrow (params)
		anColumnType <- integer (0)

		tmDataTypeSzBegin <- Sys.time ()

		# Sums the number of NAs in each column since NA values should not be inlcuded when calculating max size
		# is.na includes NaN so will add these back in for numeric values.
		anColumnNAs <- colSums (is.na (params))

		tryCatch ({

			for (nColumn in seq_len (ncol (params))) {

				oValue <- aaoColumns [[nColumn]] [1] # examine first row values to determine data types

				if (bit64::is.integer64 (oValue)) { # must be checked before is.numeric
					anColumnType <- c (anColumnType, 1L)
					# convert this column to character since bit64 is not handled well in Rcpp
					params [[nColumn]] <- bit64::as.character.integer64 (params [[nColumn]])
					# Size of this column is the length of chars (8) plus size of column for each row but exclude all NA columns
					nMaxSize <- nMaxSize + 8 * (nNumOfRows - anColumnNAs [[nColumn]])
					nMaxSize <- nMaxSize + sum (nchar (params [[nColumn]], type="bytes"), na.rm=TRUE)

				} else if (inherits (oValue, "Date")) { # there is no is.Date function
					anColumnType <- c (anColumnType, 2L)
					# Size of this column is the length of chars (8) plus size of Date (10) but exclude all NA columns
					nMaxSize <- nMaxSize + 18 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else if (is.integer (oValue)) { # must be checked before is.numeric
					anColumnType <- c (anColumnType, 3L)
					nMaxSize <- nMaxSize + 4 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else if (is.numeric (oValue)) {
					anColumnType <- c (anColumnType, 4L)
					# Add length of numeric (8 bytes) for every row that is not NA but keep NaNs (is.na includes NaN values)
					nMaxSize <- nMaxSize + 8 * (nNumOfRows - anColumnNAs [[nColumn]] + sum (is.nan( params [[nColumn]]))) # add length of characters for each row

				} else if (any (sapply (aaoColumns [[nColumn]], is.raw))) { # examine entire column not just first row
					anColumnType <- c (anColumnType, 5L)
					# Add size of length (8 bytes) for every row that is not NA and then get sum
					# of each column in row by calling Rcpp. Can be done in R but faster using Rcpp
					nMaxSize <- nMaxSize + 8 * (nNumOfRows - anColumnNAs [[nColumn]])
					nMaxSize <- nMaxSize + rawToInteger64LE (envGlobals$sumRawLengthRcpp (params [[nColumn]]))

				} else if (hms::is_hms (oValue)) { # must be checked before difftime
					anColumnType <- c (anColumnType, 6L)
					params [[nColumn]] <- as.character (params [[nColumn]])
					# Add size of length (8 bytes) plus length of hms (15) but exclude all NA columns
					nMaxSize <- nMaxSize + 23 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else if (inherits (oValue, "difftime")) { # there is no is.difftime function
					anColumnType <- c (anColumnType, 7L)
					params [[nColumn]] <- as.double (params [[nColumn]], units = "secs")
					# Add size of length (8 bytes) plus maximum length of difftime (22) but exclude all NA values
					nMaxSize <- nMaxSize + 30 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else if (is.TimeWithTimeZone (oValue)) {
					anColumnType <- c (anColumnType, 8L)
					# Add size of length (8 bytes) plus length of time with time zone (21) but exclude all NA values
					nMaxSize <- nMaxSize + 29 * (nNumOfRows - anColumnNAs [[nColumn]])
					params [[nColumn]] <- format.TimeWithTimeZone (params [[nColumn]], "TimeWithTimeZone")

				} else if (is.Timestamp (oValue)) {
					anColumnType <- c (anColumnType, 9L)
					params [nColumn] <- lapply (params [nColumn], formatTimeValue, "POSIXt")
					# Add size of length (8 bytes) plus length of time with time zone (26) but exclude all NA values
					nMaxSize <- nMaxSize + 34 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else if (is.TimestampWithTimeZone (oValue)) {
					anColumnType <- c (anColumnType, 10L)
					params [nColumn] <- lapply (params [nColumn], formatTimeValue, "POSIXlt")
					# Add size of length (8 bytes) plus length of time with time zone (32) but exclude all NA values
					nMaxSize <- nMaxSize + 40 * (nNumOfRows - anColumnNAs [[nColumn]])

				} else { # convert everything else to its character representation
					anColumnType <- c (anColumnType, 11L)
					if (is.factor (oValue) || is.list (oValue)) {
						params [[nColumn]] <- as.character (params [[nColumn]])
					}

					# Add size of length (8 bytes) for each row but exclude NA values
					nMaxSize <- nMaxSize + 8 * (nNumOfRows - anColumnNAs [[nColumn]])
					nMaxSize <- nMaxSize + sum (nchar (params [[nColumn]], type="bytes"), na.rm=TRUE)
				}
			} # end for nColumn
		}, error = function (ex) {
			stop (paste0 ("Error occurred in obtainRows while calculating buffer size: ", ex))
		})

		# Add character for every field type & for every end row value ('Z') and one for end of records ('Z')
		nMaxSize <- nMaxSize + nNumOfRows * ncol (params) + nNumOfRows + 1

		if (res@m_con@m_bTimingLog) {
			timingLog (paste0 ("Time calculating data types & size took ", elapsedTimeFormat (tmDataTypeSzBegin, Sys.time ())))
		}

		if (res@m_con@m_bDebugLog) {
			cat ("obtainRows calculating size and types done:\n")
			print (params)
			cat (paste0 ("obtainRows max buffer size=", nMaxSize, "\n"))
		}

		# Long vectors (greater than max int value) are not supported in .C calls (5th param in rgoCreateRows call)
		if (nMaxSize > .Machine$integer.max) {
			stop (paste0 ("The size of data ", nMaxSize, " exceeds ", .Machine$integer.max, ", which is the maximum size of a vector parameter passed to a .C function (rgoCreateRows)"))
		}

		tmSerialRowsRcppBegin <- Sys.time ()

		abyBindValues <- envGlobals$serializeRowsRcpp (
			integer64ToRawLE (bit64::as.integer64 (res@m_con@m_uLog)),
			integer64ToRawLE (nMaxSize),
			anColumnType,
			params
		)

		if (res@m_con@m_bTimingLog) {
			timingLog (paste0 ("Time in serializeRowsRcpp took ", elapsedTimeFormat (tmSerialRowsRcppBegin, Sys.time ())))
		}

	} else {
		abyBindValues = charToRaw ("Z")
	}

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainRows len=", length (abyBindValues), " abyBindValues=", paste0 (format (abyBindValues), collapse = " "), "\n"))
	}

	tmRgoCreateRowsBegin <- Sys.time ()

	result <- .C ("rgoCreateRows",
		uLog                 = res@m_con@m_uLog,
		uConnHandle          = res@m_con@m_uConnHandle,
		sRequestText         = sRequestText,
		uBindValuesByteCount = bit64::as.integer64 (length (abyBindValues)),
		abyBindValues        = abyBindValues,
		nErrorByteCount      = 0L,
		uErrorPtr            = bit64::as.integer64 (0),
		uRowsHandle          = bit64::as.integer64 (0),
		PACKAGE              = envGlobals$sDynLoadPackageName
	)

	tmRgoCreateRowsTotal <- Sys.time () - tmRgoCreateRowsBegin

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	res@m_envMutable$uRowsHandle <- result$uRowsHandle
	res@m_envMutable$uFetchedRowCount <- bit64::as.integer64 (0)
	res@m_envMutable$bCompleted <- FALSE

	obtainColumnMetaData (res)

	if (res@m_con@m_bTimingLog) {
		tmObtainRowsEnd <- Sys.time ()
		timingLog (paste0 ("Time in obtainRows took ", elapsedTimeFormat (tmObtainRowsBegin, tmObtainRowsEnd)))
		timingLog (paste0 ("Time in obtainRows excluding time in rgoCreateRows took ", elapsedTimeFormat (tmObtainRowsBegin, tmObtainRowsEnd - tmRgoCreateRowsTotal)))
	}

	invisible (res)

} # end obtainRows

obtainColumnMetaData <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter obtainColumnMetaData ", res, "\n"))
		on.exit (cat (paste0 ("< leave obtainColumnMetaData ", res, "\n")))
	}

	result <- .C ("rgoResultMetaData",
		uLog                     = res@m_con@m_uLog,
		uRowsHandle              = res@m_envMutable$uRowsHandle,
		nErrorByteCount          = 0L,
		uErrorPtr                = bit64::as.integer64 (0),
		uActivityCount           = bit64::as.integer64 (0),
		nColumnMetaDataByteCount = 0L,
		uColumnMetaDataPtr       = bit64::as.integer64 (0),
		PACKAGE                  = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	res@m_envMutable$uActivityCount <- result$uActivityCount

	resultColumnMetaData <- .C ("rgoFreeRawPointer",
		uLog       = res@m_con@m_uLog,
		nByteCount = result$nColumnMetaDataByteCount,
		uPtr       = result$uColumnMetaDataPtr,
		aby        = as.raw (seq (66, 66, length = result$nColumnMetaDataByteCount)), # prefill with 'B' characters
		PACKAGE    = envGlobals$sDynLoadPackageName
	)

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainColumnMetaData resultColumnMetaData$aby = ", paste0 (format (resultColumnMetaData$aby), collapse = " "), "\n"))
	}

	resultPOSIXlt <- .C ("rgoResultPOSIXlt",
		uLog            = res@m_con@m_uLog,
		uRowsHandle     = res@m_envMutable$uRowsHandle,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		bResultPOSIXlt  = FALSE,
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (resultPOSIXlt$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = resultPOSIXlt$nErrorByteCount,
			uErrorPtr       = resultPOSIXlt$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = resultPOSIXlt$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainColumnMetaData resultPOSIXlt$bResultPOSIXlt = ", resultPOSIXlt$bResultPOSIXlt, "\n"))
	}

	envByRef <- new.env (parent = emptyenv ()) # use an environment for pass-by-reference
	envByRef$listColumnwiseLists <- list ()

	i <- 1
	while (rawToChar (resultColumnMetaData$aby [i]) != "Z") { # Z=terminator

		envByRef$row <- list ()

		# (1) Column name
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		# (2) Type name
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		# (3) Type code
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		if (envByRef$row [[length (envByRef$row)]] == "b") { # typeCode b=bytes
			envByRef$row [[length (envByRef$row)]] <- "raw"

		} else if (envByRef$row [[length (envByRef$row)]] == "d") { # typeCode d=double
			envByRef$row [[length (envByRef$row)]] <- "numeric"

		} else if (envByRef$row [[length (envByRef$row)]] == "i") { # typeCode i=integer (int32)
			envByRef$row [[length (envByRef$row)]] <- "integer"

		} else if (envByRef$row [[length (envByRef$row)]] == "l") { # typeCode l=long (int64)
			envByRef$row [[length (envByRef$row)]] <- "integer64"

		} else if (envByRef$row [[length (envByRef$row)]] == "m") { # typeCode m=number
			envByRef$row [[length (envByRef$row)]] <- "numeric"

		} else if (envByRef$row [[length (envByRef$row)]] == "s") { # typeCode s=string
			envByRef$row [[length (envByRef$row)]] <- "character"

		} else if (envByRef$row [[length (envByRef$row)]] == "u") { # typeCode u=date
			envByRef$row [[length (envByRef$row)]] <- "Date"

		} else if (envByRef$row [[length (envByRef$row)]] == "v") { # typeCode v=time
			envByRef$row [[length (envByRef$row)]] <- "hms"

		} else if (envByRef$row [[length (envByRef$row)]] == "w") { # typeCode w=time with time zone
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "TimeWithTimeZone", "character")

		} else if (envByRef$row [[length (envByRef$row)]] == "x") { # typeCode x=timestamp
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "Timestamp", "POSIXct")

		} else if (envByRef$row [[length (envByRef$row)]] == "y") { # typeCode y=timestamp with time zone
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "TimestampWithTimeZone", "character")
		}

		# (4) Max byte count
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (5) Precision
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (6) Scale
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (7) Nullable
		i <- deserializeBool (resultColumnMetaData$aby, i, envByRef)

		appendRowToColumnwiseLists (envByRef)

	} # end while

	res@m_envMutable$dfColumnMetaData <- dataFrameFromColumnwiseLists (envByRef$listColumnwiseLists, c ("name", "type", "Sclass", "len", "precision", "scale", "nullOK"))

	invisible (res)

} # end obtainColumnMetaData

#' Bind values to prepared statement parameter markers
#' `dbBind(res, params, ...)`
#' @param res A TeradataResult object
#' @param params Parameter values to bind
#' @return The TeradataResult invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("dbBind", "TeradataResult", function (res, params, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbBind ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbBind ", res, "\n")))
	}

	stopIfCleared (res)

	obtainRows (res, FALSE, params) # execute RPO=B unless overriden

	invisible (res)

}) # end method dbBind

#' Close the result
#' `dbClearResult(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("dbClearResult", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbClearResult ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbClearResult ", res, "\n")))
	}

	if (res@m_envMutable$bCleared) {
		warning ("TeradataResult is already cleared")
	} else {
		closeRows (res)
		res@m_envMutable$bCleared <- TRUE
	}

	invisible (TRUE)

}) # end method dbClearResult

closeRows <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter closeRows ", res, "\n"))
		on.exit (cat (paste0 ("< leave closeRows ", res, "\n")))
	}

	bHasOpenRows <- ! is.na (res@m_envMutable$uRowsHandle)
	if (bHasOpenRows) {

		result <- .C ("rgoCloseRows",
			uLog            = res@m_con@m_uLog,
			uRowsHandle     = res@m_envMutable$uRowsHandle,
			nErrorByteCount = 0L,
			uErrorPtr       = bit64::as.integer64 (0),
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		if (result$nErrorByteCount > 0) {

			resultErr <- .C ("rgoFreeCharPointer",
				uLog            = res@m_con@m_uLog,
				nErrorByteCount = result$nErrorByteCount,
				uErrorPtr       = result$uErrorPtr,
				sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
				PACKAGE         = envGlobals$sDynLoadPackageName
			)

			stop (resultErr$sErrorMsg)

		} # end if nErrorByteCount > 0

		res@m_envMutable$uRowsHandle <- NA

	} # end if bHasOpenRows

	invisible (bHasOpenRows)

} # end closeRows

#' Obtain result column metadata
#' `dbColumnInfo(res, ...)`
#' @param res A TeradataResult object
#' @return A data frame with columns `name` (type `character`), `Sclass` (R data type), `type` (type `character`),
#'   `len` (type `integer`), precision (type `integer`), scale (type `integer`), nullOK (type `logical`).
#'   The data frame contains one row for each result column.
#' @export
#' @rdname TeradataResult-class
setMethod ("dbColumnInfo", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbColumnInfo ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbColumnInfo ", res, "\n")))
	}

	stopIfCleared (res)

	# Just-in-time prepare operation if the app requests column metadata before execution
	if (! ("dfColumnMetaData" %in% names (res@m_envMutable))) {

		obtainRows (res, TRUE, NULL) # prepare RPO=S
		closeRows (res)
	}

	return (res@m_envMutable$dfColumnMetaData)

}) # end method dbColumnInfo

stopIfNoBind <- function (res) {

	if (is.na (res@m_envMutable$uRowsHandle)) {
		stop ("Must call dbBind before dbFetch")
	}

	invisible (TRUE)

} # end stopIfNoBind

fetchRows <- function (res, nDesiredRowCount, envByRef) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter fetchRows ", res, " nDesiredRowCount = ", nDesiredRowCount, "\n"))
		on.exit (cat (paste0 ("< leave fetchRows ", res, " fetched ", result$nRowCount, " rows\n")))
	}

	stopIfCleared (res)
	stopIfNoBind (res)

	if (nDesiredRowCount == 0) {
		return (FALSE)
	}

	# Need to pass as byte array because negative values are not accepted & -1 means all available rows
	abyDesiredRowCount = integer64ToRaw (nDesiredRowCount)

	tmRgoFetchRowsBeg <- Sys.time ()
	#Unless formal argument NAOK is true, all the other arguments are checked for missing values NA
	result <- .C ("rgoFetchRows",
		uLog                   = res@m_con@m_uLog,
		uRowsHandle            = res@m_envMutable$uRowsHandle,
		nErrorByteCount        = 0L,
		uErrorPtr              = bit64::as.integer64 (0),
		nRowCount              = bit64::as.integer64 (0),
		abyDesiredRowCount     = abyDesiredRowCount,
		nColumnValuesByteCount = 0L,
		uColumnValuesPtr       = bit64::as.integer64 (0),
		PACKAGE                = envGlobals$sDynLoadPackageName
	)

	envByRef$tmRgoFetchRowsTotal <- Sys.time () - tmRgoFetchRowsBeg

	res@m_envMutable$uFetchedRowCount <- res@m_envMutable$uFetchedRowCount + result$nRowCount

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	if (result$uColumnValuesPtr == 0) { # no more rows

		if (res@m_con@m_bDebugLog) {
			cat ("fetchRows returning FALSE to indicate no more rows\n")
		}

		res@m_envMutable$bCompleted <- TRUE
		return (FALSE) # indicate no more rows
	}

	row <- .C ("rgoFreeRawPointer",
		uLog                   = res@m_con@m_uLog,
		nColumnValuesByteCount = result$nColumnValuesByteCount,
		uColumnValuesPtr       = result$uColumnValuesPtr,
		abyColumnValues        = as.raw (seq (66, 66, length = (as.double (result$nColumnValuesByteCount + 2)))), # prefill with 'B' characters
		PACKAGE                = envGlobals$sDynLoadPackageName
	)

	abyLog = integer64ToRawLE (bit64::as.integer64 (res@m_con@m_uLog))
	abyRowCount = integer64ToRawLE (result$nRowCount)
	sErrorMsg <- c ("")
	tmDeserializeRowsBegin <- Sys.time ()

	envByRef$listColumnwiseLists <- envGlobals$deserializeRowsRcpp (
		abyLog, abyRowCount,
		envByRef$nColCount,
		row$abyColumnValues,
		res@m_envMutable$dfColumnMetaData$Sclass,
		res@m_envMutable$dfColumnMetaData$type
	)

	if (res@m_con@m_bTimingLog) {
		timingLog (paste0 ("Time in deserializeRowsRcpp took ", elapsedTimeFormat (tmDeserializeRowsBegin, Sys.time ())))
	}

	return (TRUE) # indicate row is available

} # end fetchRows

#' Create a NA used for Rcpp with Raws. Needed in deserializeRowsRcpp
#'
#' `teradatasql::setNA(x)`
#'
#' @return NA
#' @export
#' @rdname setNA-class
setNA <- function ()
{
	return (NA)
}

#' Sets raw to list. Needed in deserializeRowsRcpp
#'
#' `teradatasql::rawToList(x)`
#'
#' @return sets raw to list
#' @export
#' @rdname rawToList-class
rawToList <- function (rVec)
{
	return (I (rVec))
}

elapsedTimeFormat <- function (startTime, endTime) {

	sec <- as.numeric (difftime (endTime, startTime, units = "secs"))
	min <- floor (sec / 60)
	hr  <- floor (min / 60)

	if (sec < 1) {
		return (sprintf ("%.0f ms", sec * 1000))
	}
	if (sec < 60) {
		ms <- (sec - floor (sec)) * 1000
		return (sprintf ("%d secs and %.0f ms", floor (sec), ms))
	} else if (min < 60) {
		sec <- sec - min * 60
		ms <- (sec - floor (sec)) * 1000
		return (sprintf ("%d mins and %d secs %.0f ms", min, floor (sec), ms))
	} else {
		sec <- sec - min * 60
		min <- min - hr * 60
		ms <- (sec - floor (sec)) * 1000
		return (sprintf ("%d hrs %d mins %d secs and %.0f ms", hr, min, floor (sec), ms))
	}

} # end elapsedTimeFormat

#' Fetch rows
#' `dbFetch(res, n = -1, ...)`
#' An attempt to fetch from a closed result set raises an error.
#' @param res A TeradataResult object
#' @param n Maximum number of rows to fetch. Specify n = -1 or n = Inf to fetch all remaining rows.
#'   If the n argument is not an atomic whole number greater or equal to -1 or Inf, an error is raised.
#' @return A data frame with columns and rows corresponding to result set columns and rows.
#'   If the SQL statement returned an empty result set, the data frame will have fully-typed columns but zero rows.
#'   If the SQL statement did not return a result set, the data frame will have zero columns and zero rows.
#'   The column types of the returned data frame depend on the data returned:
#'     integer for 32-bit integer values
#'     bit64::as.integer64() for 64-bit integer values
#'     numeric for numbers with a fractional component
#'     character for text
#'     raw for blobs
#'     as.Date() for dates
#'     hms::as_hms() for times
#'     as.POSIXct() for timestamps
#'     NA for SQL NULL values
#' @export
#' @rdname TeradataResult-class
setMethod ("dbFetch", "TeradataResult", function (res, n = -1, ...) {

	tmDbFetchBegin <- Sys.time ()
	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbFetch ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbFetch ", res, "\n")))
	}

	stopIfCleared (res)
	stopIfNoBind (res)

	if (is.na (n) || ! is.numeric (n) || (n != Inf && (n %% 1) != 0) || n < -1) {
		stop (paste0 ("Argument n must be a whole number -1 or greater: ", n))
	}
	nDesiredRowCount <- bit64::as.integer64 (ifelse (n == Inf, -1L, as.integer (n)))

	envByRef <- new.env (parent = emptyenv ()) # use an environment for pass-by-reference
	envByRef$listColumnwiseLists <- list ()
	envByRef$nColCount <- length (res@m_envMutable$dfColumnMetaData$name)

	if (nDesiredRowCount != 0L) {
		fetchRows (res, nDesiredRowCount, envByRef)
	}

	df <- as.data.frame (envByRef$listColumnwiseLists, stringsAsFactors = FALSE)

	if (nDesiredRowCount == -1L || nrow (df) < nDesiredRowCount) {
		res@m_envMutable$bCompleted <- TRUE
	}

	if (ncol (df) > 0) {
		colnames (df) <- res@m_envMutable$dfColumnMetaData$name
	}

	# The data.frame constructor mishandles POSIXlt values, so values derived from POSIXlt must
	# be composed and stored in the data.frame columns after the data.frame is constructed.

	# A column containing all NULL values will produce a logical vector containing all NA values,
	# and we must coerce the logical vector to the appropriate type of vector.

	# Also, the as_hms, TimeWithTimeZone, Timestamp, and TimestampWithTimeZone constructors do not accept
	# logical NA values, only NA_character_ values, so those column vectors must be coerced to character.

	for (nColumn in seq_len (ncol (df))) {

	sColumnType <- res@m_envMutable$dfColumnMetaData$Sclass [[nColumn]]

	if      (sColumnType == "character"            ) { df [[nColumn]] <- as.character                        (df [[nColumn]])  }
	else if (sColumnType == "numeric"              ) { df [[nColumn]] <- as.numeric                          (df [[nColumn]])  }
	else if (sColumnType == "integer"              ) { df [[nColumn]] <- as.integer                          (df [[nColumn]])  }
	else if (sColumnType == "integer64"            ) { df [[nColumn]] <- bit64::as.integer64                 (df [[nColumn]])  }
	else if (sColumnType == "Date"                 ) { df [[nColumn]] <- as.Date                             (df [[nColumn]])  }
	else if (sColumnType == "hms"                  ) { df [[nColumn]] <- hms::as_hms           (as.character (df [[nColumn]])) }
	else if (sColumnType == "POSIXct"              ) { df [[nColumn]] <- as.POSIXct            (as.character (df [[nColumn]]), tz = "GMT") }
	else if (sColumnType == "TimeWithTimeZone"     ) { df [[nColumn]] <- TimeWithTimeZone      (as.character (df [[nColumn]])) }
	else if (sColumnType == "Timestamp"            ) { df [[nColumn]] <- Timestamp             (as.character (df [[nColumn]])) }
	else if (sColumnType == "TimestampWithTimeZone") { df [[nColumn]] <- TimestampWithTimeZone (as.character (df [[nColumn]])) }

	} # end for

	if (res@m_con@m_bTimingLog) {
		timingLog (paste0 (" Time in dbFetch took ", elapsedTimeFormat (tmDbFetchBegin, Sys.time ())))
		timingLog (paste0 (" Time in dbFetch excluding time in rgoFetchRows ", elapsedTimeFormat (tmDbFetchBegin, Sys.time () - envByRef$tmRgoFetchRowsTotal)))
	}

	return (df)

}) # end method dbFetch

# dbGetInfo - use superclass implementation

#' Obtain the number of rows fetched
#' `dbGetRowCount(res, ...)`
#' @param res A TeradataResult object
#' @return The number of rows fetched so far
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetRowCount", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetRowCount ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetRowCount ", res, " Fetched Row Count ", res@m_envMutable$uFetchedRowCount, "\n")))
	}

	stopIfCleared (res)

	nMaxValue <- 9007199254740991
	if (res@m_envMutable$uFetchedRowCount > nMaxValue) {

		warning (paste0 ("Actual row count ", res@m_envMutable$uFetchedRowCount, " exceeds the maximum numeric value ", nMaxValue))
		return (nMaxValue)
	}

	return (bit64::as.double.integer64 (res@m_envMutable$uFetchedRowCount))

}) # end method dbGetRowCount

#' Obtain the number of rows affected by the SQL statement
#' `dbGetRowsAffected(res, ...)`
#' @param res A TeradataResult object
#' @return The number of rows affected by the SQL statement
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetRowsAffected", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetRowsAffected ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetRowsAffected ", res, "\n")))
	}

	stopIfCleared (res)

	nMaxValue <- 9007199254740991
	if (res@m_envMutable$uActivityCount > nMaxValue) {

		warning (paste0 ("Actual row count ", res@m_envMutable$uActivityCount, " exceeds the maximum numeric value ", nMaxValue))
		return (nMaxValue)
	}

	return (bit64::as.double.integer64 (res@m_envMutable$uActivityCount))

}) # end method dbGetRowsAffected

#' Obtain the SQL request text
#' `dbGetStatement(res, ...)`
#' @param res A TeradataResult object
#' @return The SQL request text
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetStatement", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetStatement ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetStatement ", res, "\n")))
	}

	stopIfCleared (res)

	return (res@m_sOperation)

}) # end method dbGetStatement

#' Determine whether the entire result has been fetched
#' `dbHasCompleted(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` if all rows have been fetched, `FALSE` otherwise
#' @export
#' @rdname TeradataResult-class
setMethod ("dbHasCompleted", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbHasCompleted ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbHasCompleted ", res, "\n")))
	}

	stopIfCleared (res)

	return (res@m_envMutable$bCompleted)

}) # end method dbHasCompleted

# dbIsReadOnly - use superclass implementation

#' Determine whether the result is usable
#' `dbIsValid(dbObj, ...)`
#' @param dbObj A TeradataResult object
#' @return `TRUE` to indicate that the result is usable, `FALSE` otherwise
#' @export
#' @rdname TeradataResult-class
setMethod ("dbIsValid", "TeradataResult", function (dbObj, ...) {

	res <- dbObj

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbIsValid ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbIsValid ", res, "\n")))
	}

	return (! res@m_envMutable$bCleared)

}) # end method dbIsValid

setGeneric (name = "dbNextResult", def = function (res, ...) {
	standardGeneric ("dbNextResult")
})

#' Advances to the next result set.
#' `dbNextResult(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` if there are more result sets; otherwise `FALSE`
#' @export
#' @rdname TeradataResult-class
setMethod ("dbNextResult", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbNextResult ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbNextResult ", res, "\n")))
	}

	stopIfCleared (res)

	result <- .C ("rgoNextResult",
		uLog            = res@m_con@m_uLog,
		uRowsHandle     = res@m_envMutable$uRowsHandle,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		pcAvail         = as.character (0),
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	bAvail <- result$pcAvail == "Y"
	if (bAvail) {
		obtainColumnMetaData (res)
		res@m_envMutable$uFetchedRowCount <- bit64::as.integer64 (0)
	}

	return (bAvail)

}) # end method dbNextResult

setGeneric (name = "setFetchedRowCount", def = function (res, u, ...) {
	standardGeneric ("setFetchedRowCount")
})

#' Sets the fetched row count for testing.
#' `setFetchedRowCount(res, ...)`
#' @param res A TeradataResult object
#' @param u The fetched row count
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("setFetchedRowCount", "TeradataResult", function (res, u, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter setFetchedRowCount ", res, " u=", u, "\n"))
		on.exit (cat (paste0 ("< leave setFetchedRowCount ", res, " u=", u, "\n")))
	}

	res@m_envMutable$uFetchedRowCount <- u
	invisible (TRUE)

}) # end method setFetchedRowCount
