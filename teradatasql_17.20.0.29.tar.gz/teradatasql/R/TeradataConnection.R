# Copyright 2018 by Teradata Corporation. All Rights Reserved.
# TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#' TeradataConnection class
#'
#' @keywords internal
#' @import bit64
#' @import DBI
#' @import methods
#' @export
#' @rdname TeradataConnection-class
setClass ("TeradataConnection", contains = "DBIConnection",
	slots = c (
		m_uLog        = "integer64",
		m_bImmediate  = "logical",
		m_bTraceLog   = "logical",
		m_bDebugLog   = "logical",
		m_bTimingLog  = "logical",
		m_uConnHandle = "integer64",
		m_envMutable  = "environment"
	)
)

setMethod ("as.character", "TeradataConnection", function (x, ...) {

	conn <- x

	return (paste0 ("TeradataConnection",
		" Driver="     , envGlobals$sDriverVersion,
		" Database="   , conn@m_envMutable$sDatabaseVersion,
		" Host="       , conn@m_envMutable$sHost,
		" uConnHandle=", conn@m_uConnHandle))

}) # end method as.character

setMethod ("show", "TeradataConnection", function (object) {

	cat (paste0 ("<", object, ">\n")) # implicitly calls as.character for the object
	invisible (NULL)

}) # end method show

encodeForJSON <- function (x) {

	if (is.logical (x) && length (x) == 1 && ! is.na (x)) {
		x <- tolower (toString (x)) # use lowercase words true and false
	}

	x <- toString (x) # convert to string if not already

	x <- gsub ('\\', '\\\\', x, fixed = TRUE) # replace each backslash with two backslashes
	x <- gsub ('"' , '\\"' , x, fixed = TRUE) # replace each double-quote with backslash double-quote

	return (paste0 ('"', x, '"')) # enclose in double-quotes

} # end encodeForJSON

formatListAsJSON <- function (x) {

		asPairs <- character (0)

		for (nColumn in seq_along (x)) {

			sKey    <- encodeForJSON (names (x) [[nColumn]])
			sValue  <- encodeForJSON (x [[nColumn]])
			asPairs <- c (asPairs, paste0 (sKey, ":", sValue))
		}

		return (paste0 ("{", toString (asPairs), "}"))

} # end formatListAsJSON

constructTeradataConnection <- function (sConnectParams, ...) {

	if (all (is.na (sConnectParams))) {
		sConnectParams <- ""
	}

	if (! is.character (sConnectParams)) {
		stop ("Connection parameters must be specified as a character value")
	}

	if (length (sConnectParams) != 1) {
		stop ("Connection parameters must be a specified as single JSON character value")
	}

	if (sConnectParams == "") {
		sConnectParams <- "{}"
	}

	# Compose a streamlined stack trace of script file names and package names
	asStack       <- character (0)
	asCalls       <- limitedLabels (sys.calls ())
	listFrameEnvs <- sys.frames () # asCalls and listFrameEnvs have parallel indexes
	for (i in seq_along (asCalls)) {
		envFrame <- listFrameEnvs [[i]]
		sPackageName <- getPackageName (envFrame)
		if (sPackageName != ".GlobalEnv" && sPackageName != "base") { # use the package name if present
			if (! (sPackageName %in% asStack)) { # avoid duplicate entries
				asStack <- c (asStack, sPackageName)
			}
		} else if (grepl ("^[^#]+#\\d+: ", asCalls [[i]])) { # otherwise use the R script filename if present
			sScriptName <- sub ("#.*", "", asCalls [[i]])
			if (! (sScriptName %in% asStack)) { # avoid duplicate entries
				asStack <- c (asStack, sScriptName)
			}
		} # end else if
	} # end for

	listKwArgs <- list (...)

	listKwArgs$client_kind   <- "R" # G = Go, P = Python, R = R, S = Node.js
	listKwArgs$client_vmname <- paste (R.version.string, R.version$nickname, R.version$platform)
	listKwArgs$client_osname <- paste (Sys.info () ["sysname"], Sys.info () ["release"], Sys.info () ["version"], Sys.info () ["machine"])
	listKwArgs$client_stack  <- paste0 (asStack, collapse = " ")
	listKwArgs$client_extra  <- paste0 ("R=", R.version$major, ".", R.version$minor, ";TZ=", Sys.timezone (), ";") # must be semicolon-terminated

	sConnectArgs <- formatListAsJSON (listKwArgs)

	result <- .C ("rgoCombineJSON",
		pcConnectParams    = sConnectParams,
		pcConnectArgs      = sConnectArgs,
		nErrorByteCount    = 0L,
		uErrorPtr          = bit64::as.integer64 (0),
		nCombinedByteCount = 0L,
		uCombinedPtr       = bit64::as.integer64 (0),
		PACKAGE            = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = bit64::as.integer64 (0), # we don't have uLog yet
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	result <- .C ("rgoFreeCharPointer",
		uLog               = bit64::as.integer64 (0), # we don't have uLog yet
		nCombinedByteCount = result$nCombinedByteCount,
		uCombinedPtr       = result$uCombinedPtr,
		sCombined          = rawToChar (as.raw (seq (65, 65, length = result$nCombinedByteCount))), # prefill with 'A' characters
		PACKAGE            = envGlobals$sDynLoadPackageName
	)

	sConnectParams <- result$sCombined

	result <- .C ("rgoParseParams",
		pcConnectParams = sConnectParams,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		uLog            = bit64::as.integer64 (0),
		bImmediate      = FALSE,
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = bit64::as.integer64 (0), # if rgoParseParams failed, then we don't have uLog
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	uLog       <- result$uLog
	bImmediate <- result$bImmediate

	sFormattedLogBits <- bit64::as.bitstring (uLog)
	bTraceLog  <- substr (sFormattedLogBits, 64, 64) == "1"
	bDebugLog  <- substr (sFormattedLogBits, 63, 63) == "1"
	bTimingLog <- substr (sFormattedLogBits, 61, 61) == "1"

	if (bTraceLog) {
		cat (paste0 ("> enter TeradataConnection\n"))
		on.exit (cat (paste0 ("< leave TeradataConnection\n")))
	}

	result <- .C ("rgoCreateConnection",
		uLog            = uLog,
		pcVersionNumber = envGlobals$sDriverVersion,
		pcConnectParams = sConnectParams,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		uConnHandle     = bit64::as.integer64 (0),
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	conn <- new ("TeradataConnection",
		m_uLog        = uLog,
		m_bImmediate  = bImmediate,
		m_bTraceLog   = bTraceLog,
		m_bDebugLog   = bDebugLog,
		m_bTimingLog  = bTimingLog,
		m_uConnHandle = result$uConnHandle,
		m_envMutable  = new.env (parent = emptyenv ()) # use an environment to hold mutable instance variables
	)

	conn@m_envMutable$sDatabaseVersion  <- NA # must initialize because of reference by as.character
	conn@m_envMutable$sHost             <- NA # must initialize because of reference by as.character
	conn@m_envMutable$sPort             <- NA # must initialize because of reference by as.character

	conn@m_envMutable$sDatabaseVersion  <- DBI::dbGetQuery (conn, "{fn teradata_nativesql}{fn teradata_database_version}"          ) [1, 1]
	conn@m_envMutable$sHost             <- DBI::dbGetQuery (conn, "{fn teradata_nativesql}{fn teradata_provide(original_hostname)}") [1, 1]
	conn@m_envMutable$sPort <- as.integer (DBI::dbGetQuery (conn, "{fn teradata_nativesql}{fn teradata_provide(remote_port)}"      ) [1, 1])

	if (bDebugLog) {
		cat (paste0 ("Returning ", conn, "\n"))
	}

	return (conn)

} # end constructTeradataConnection

logMsg <- function (sCategory, sTitle) {

	sTitle <- gsub ("\r", "\\\\r", sTitle)
	sTitle <- gsub ("\n", "\\\\n", sTitle)

	sCallingFunction <- paste0 (deparse(sys.calls()[[sys.nframe()-2]] [[1]]))

	sOutput <- paste0 (strftime (Sys.time (),"%Y-%m-%d.%H:%M:%OS3"), " [", Sys.getpid (), "] RDBI-", sCategory, " ", sCallingFunction, " ", sTitle, "\n")

	cat (sOutput)
	flush.console ()

} # end LogMsgEx

timingLog <- function (sTitle) { logMsg ("TIMING", sTitle) }

#' Insert rows into an existing table
#' `dbAppendTable(conn, name, value, row.names = NULL, ...)`
#' @param name Name of the table escaped with `dbQuoteIdentifier`.
#' @param value A data frame of values. The column names must match the destination table column names.
#' @param row.names Not supported. Must be `NULL`. Process the values with `sqlRownamesToColumn` before calling this method.
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbAppendTable", "TeradataConnection", function (conn, name, value, ..., row.names = NULL) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbAppendTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbAppendTable ", conn, "\n")))
	}

	if (! is.null (row.names)) {
		stop ("dbAppendTable row.names must be NULL")
	}

	sSQL <- DBI::sqlAppendTableTemplate (
		con       = conn,
		table     = name,
		values    = value,
		row.names = FALSE, # do not translate row names
		prefix    = "?", # compose SQL request text with question-mark parameter markers
		pattern   = "",
		...)

	if (conn@m_bDebugLog) {
		cat (paste0 ("dbAppendTable ", sSQL, "\n"))
	}

	DBI::dbExecute (conn, sSQL, params = value)

}) # end method dbAppendTable

#' Begin a transaction
#' `dbBegin(conn, ...)`
#' @param conn A TeradataConnection object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbBegin", "TeradataConnection", function (conn, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbBegin ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbBegin ", conn, "\n")))
	}

	DBI::dbExecute (conn, "{fn teradata_nativesql}{fn teradata_autocommit_off}")
	invisible (TRUE)

}) # end method dbBegin

#' Commit the current transaction
#' `dbCommit(conn, ...)`
#' @param conn A TeradataConnection object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbCommit", "TeradataConnection", function (conn, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbCommit ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbCommit ", conn, "\n")))
	}

	DBI::dbExecute (conn, "{fn teradata_commit}{fn teradata_autocommit_on}")
	invisible (TRUE)

}) # end method dbCommit

# dbCreateTable - use superclass implementation

#' Determine the SQL data type of an R object
#' `dbDataType(dbObj, obj, ...)`
#' @param dbObj A TeradataConnection object
#' @param obj An R object whose SQL type we want to determine
#' @return A string giving the SQL data type for the R object
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbDataType", "TeradataConnection", function (dbObj, obj, ...) {

	conn <- dbObj

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbDataType ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbDataType ", conn, "\n")))
	}

	sReturn <- getSQLTypeName (obj)

	if (conn@m_bDebugLog) {
		cat (paste0 ("dbDataType class=", class (obj) [[1]], " typeof=", typeof (obj), " isListOfRaw=", isListOfRaw (obj), " sReturn=", sReturn, "\n"))
	}

	return (sReturn)

}) # end method dbDataType

#' Close the connection
#' `dbDisconnect(conn, ...)`
#' @param conn A TeradataConnection object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbDisconnect", "TeradataConnection", function (conn, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbDisconnect", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbDisconnect ", conn, "\n")))
	}

	result <- .C ("rgoCloseConnection",
		uLog            = conn@m_uLog,
		uConnHandle     = conn@m_uConnHandle,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = conn@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	invisible (TRUE)

}) # end method dbDisconnect

#' Execute a SQL request
#' `dbExecute(conn, statement, ...)`
#' @param conn A TeradataConnection object
#' @param statement A character string containing the SQL request text
#' @return A TeradataResult object
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbExecute", signature ("TeradataConnection", "character"), function (conn, statement, params = NULL, immediate = TRUE, ...) {

	# Optional arguments params and immediate appear before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbExecute ", conn, " immediate=", immediate, " ", statement, "\n"))
		on.exit (cat (paste0 ("< leave dbExecute ", conn, " immediate=", immediate, " ", statement, "\n")))
	}

	res <- DBI::dbSendQuery (conn, statement, params = params, immediate = immediate)
	tryCatch ({

		return (DBI::dbGetRowsAffected (res))

	}, finally = {

		DBI::dbClearResult (res)

	}) # end finally

}) # end method dbExecute

getErrorCode <- function (sInput) {

	sPattern <- ".*\\[Error (\\d+)\\].*"

	if (grepl (sPattern, sInput)) {
		return (as.integer (sub (sPattern, "\\1", sInput)))
	} else {
		return (NA)
	}
} # end getErrorCode

#' Determine whether a table exists
#' `dbExistsTable(conn, name, ...)`
#' @param conn A TeradataConnection object
#' @param name A character string specifying a table name
#' @return `TRUE` if the specified table or view exists, `FALSE` otherwise
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbExistsTable", signature ("TeradataConnection", "character"), function (conn, name, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbExistsTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbExistsTable ", conn, "\n")))
	}

	return (existsTable (conn, name))

}) # end method dbExistsTable

#' @export
#' @rdname TeradataConnection-class
setMethod ("dbExistsTable", signature ("TeradataConnection", "Id"), function (conn, name, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbExistsTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbExistsTable ", conn, "\n")))
	}

	return (existsTable (conn, name))

}) # end method dbExistsTable

# This function is only intended for use with qualified and unqualified table names.
# This function is not intended for use with a schema name in the form DBI::Id(schema = "myschema")
# Note that DBI::dbQuoteIdentifier(conn, DBI::Id(schema = "myschema")) strips the schema intent.
normalizeTableName <- function (conn, x) {

	x <- DBI::dbUnquoteIdentifier (conn, DBI::dbQuoteIdentifier (conn, x))

	if (length (x) != 1) {
		stop (paste0 ("Name must be a single value but has length ", length (x)))
	}

	x <- x [[1]]
	x <- x@name
	return (x)

} # end normalizeTableName

getTableNameComponent <- function (conn, x, sComponent) {

	x <- normalizeTableName (conn, x)

	if (sComponent %in% names (x)) {
		return (x [[sComponent]])
	} else {
		return (NA)
	}
} # end getTableNameComponent

getSchemaName <- function (conn, x) {

	return (getTableNameComponent (conn, x, "schema"))

} # end getSchemaName

getTableName <- function (conn, x) {

	return (getTableNameComponent (conn, x, "table"))

} # end getTableName

existsTable <- function (conn, name, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter existsTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave existsTable ", conn, "\n")))
	}

	sSchemaName <- getSchemaName (conn, name) # may be NA
	sTableName  <- getTableName  (conn, name)

	if (is.na (sSchemaName)) {
		sSchemaName <- "database" # use built-in function and do not quote as a literal
	} else {
		sSchemaName <- DBI::dbQuoteLiteral (conn, sSchemaName)
	}

	sTableName <- DBI::dbQuoteLiteral (conn, sTableName)

	sSQL <- DBI::SQL (paste0 (
		"select TableName from DBC.TablesV where DatabaseName (not casespecific) = ",
		sSchemaName, " (not casespecific) and TableName (not casespecific) = ",
		sTableName, " (not casespecific) and TableKind in ('O','T','V')"))

	if (conn@m_bDebugLog) {
		cat (paste0 ("existsTable ", sSQL, "\n"))
	}

	# If we find the object in the Data Dictionary, then we are done.

	nRowCount <- DBI::dbExecute (conn, sSQL)
	if (nRowCount > 0) {
		return (TRUE)
	}

	# If we do not find the object in the Data Dictionary, we need to try a different approach,
	# because the object may be a volatile table, which is not recorded in the Data Dictionary.

	sSQL <- DBI::SQL (paste0 ("show table ", DBI::dbQuoteIdentifier (conn, name)))

	if (conn@m_bDebugLog) {
		cat (paste0 ("existsTable ", sSQL, "\n"))
	}

	tryCatch ({

		DBI::dbExecute (conn, sSQL)
		return (TRUE)

	}, error = function (e) {

		nErrorCode <- getErrorCode (e) # will be NA if error code cannot be parsed

		if (conn@m_bDebugLog) {
			sFirstLine <- strsplit (trimws (e), "\n") [[1]] [[1]]
			cat (paste0 ("existsTable error code ", nErrorCode, " from ", sFirstLine, "\n"))
		}

		if (nErrorCode == 3807) {
			return (FALSE)
		} else {
			stop (e)
		}
	}) # end error

} # end existsTable

# dbGetException - deprecated method not implemented

#' Obtain metadata from the connection
#' `dbGetInfo(dbObj, ...)`
#' @param dbObj A TeradataConnection object
#' @return A named list
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbGetInfo", "TeradataConnection", function (dbObj, ...) {

	conn <- dbObj

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbGetInfo ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbGetInfo ", conn, "\n")))
	}

	sSQL <- DBI::SQL ("select database, user")

	if (conn@m_bDebugLog) {
		cat (paste0 ("dbGetInfo ", sSQL, "\n"))
	}

	df <- DBI::dbGetQuery (conn, sSQL)

	return (list (
		db.version = conn@m_envMutable$sDatabaseVersion,
		dbname     = df [1, 1],
		username   = df [1, 2],
		host       = conn@m_envMutable$sHost,
		port       = conn@m_envMutable$sPort
	))
}) # end method dbGetInfo

#' Execute a query
#' `dbGetQuery(conn, statement, ...)`
#' @param conn A TeradataConnection object
#' @param statement A character string containing the SQL request text
#' @return A TeradataResult object
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbGetQuery", signature ("TeradataConnection", "character"), function (conn, statement, n = -1, params = NULL, immediate = TRUE, ...) {

	# Optional arguments params and immediate appear before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbGetQuery ", conn, " immediate=", immediate, " ", statement, "\n"))
		on.exit (cat (paste0 ("< leave dbGetQuery ", conn, " immediate=", immediate, " ", statement, "\n")))
	}

	res <- DBI::dbSendQuery (conn, statement, params = params, immediate = immediate)
	tryCatch ({

		return (DBI::dbFetch (res, n = n))

	}, finally = {

		DBI::dbClearResult (res)

	}) # end finally

}) # end method dbGetQuery

# dbIsReadOnly - use superclass implementation

#' Determine whether the connection is usable
#' `dbIsValid(dbObj, ...)`
#' @param dbObj A TeradataConnection object
#' @return `TRUE` to indicate that the connection is usable, `FALSE` otherwise
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbIsValid", "TeradataConnection", function (dbObj, ...) {

	conn <- dbObj

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbIsValid ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbIsValid ", conn, "\n")))
	}

	result <- .C ("rgoPingConnection",
		uLog        = conn@m_uLog,
		uConnHandle = conn@m_uConnHandle,
		nStatus     = 0L,
		PACKAGE     = envGlobals$sDynLoadPackageName
	)

	return (result$nStatus > 0)

}) # end method dbIsValid

#' Obtain a table's column names
#' `dbListFields(conn, name, ...)`
#' @param conn A TeradataConnection object
#' @param name A character string specifying a table name
#' @return A character vector of the specified table's column names, in order
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbListFields", signature ("TeradataConnection", "character"), function (conn, name, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbListFields ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbListFields ", conn, "\n")))
	}

	return (getColumnNames (conn, name))

}) # end method dbListFields

#' @export
#' @rdname TeradataConnection-class
setMethod ("dbListFields", signature ("TeradataConnection", "Id"), function (conn, name, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbListFields ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbListFields ", conn, "\n")))
	}

	return (getColumnNames (conn, name))

}) # end method dbListFields

getColumnNames <- function (conn, name) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter getColumnNames ", conn, "\n"))
		on.exit (cat (paste0 ("< leave getColumnNames ", conn, "\n")))
	}

	normalizeTableName (conn, name) # for validation

	sSQL <- DBI::SQL (paste0 ("help column ", DBI::dbQuoteIdentifier (conn, name), ".*"))

	if (conn@m_bDebugLog) {
		cat (paste0 ("getColumnNames ", sSQL, "\n"))
	}

	df <- DBI::dbGetQuery (conn, sSQL)

	return (df [, 32]) # column 32 contains the Column Dictionary Name VARCHAR(128)

} # end getColumnNames

#' Obtain the list of databases, tables, and views in the system
#' `dbListObjects(conn, prefix, ...)`
#' @param conn A TeradataConnection object
#' @param prefix A database name or `NULL`.
#' @return A data frame with columns `table` (type `list` of `Id`) and `is_prefix` (type `logical`).
#'   When `NULL` is specified for `prefix`, the data frame contains one row for each database, table, and view in the system.
#'   When a database name is specified for `prefix`, the data frame contains one row for each table and view in the specified database.
#'   Data frame rows for each database have `is_prefix == TRUE`. Data frame rows for each table and view have `is_prefix == FALSE`.
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbListObjects", signature ("TeradataConnection", "ANY"), function (conn, prefix = NULL, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbListObjects ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbListObjects ", conn, "\n")))
	}

	if (is.null (prefix)) {

		sSQL <- DBI::SQL ("select DatabaseName from DBC.DatabasesV")

		if (conn@m_bDebugLog) {
			cat (paste0 ("dbListObjects ", sSQL, "\n"))
		}

		df <- DBI::dbGetQuery (conn, sSQL)

		if (ncol (df) == 0) {
			return (data.frame (table = I (list ()), is_prefix = logical (), stringsAsFactors = FALSE)) # return zero rows
		}

		listSchemas <- list ()
		for (nRow in seq_len (nrow (df))) {
			listSchemas [[nRow]] <- DBI::Id (schema = df [nRow, 1])
		}

		return (data.frame (table = I (listSchemas), is_prefix = TRUE, stringsAsFactors = FALSE))

	} # end if is.null

	if (length (prefix) != 1) {
		stop (paste0 ("Argument prefix length ", length (prefix), " differs from the required length 1"))
	}

	if (is.character (prefix)) {
		prefix <- DBI::Id (schema = prefix)
	}

	if (! inherits (prefix, "Id")) {
		stop (paste0 ("Argument prefix class ", class (prefix) [[1]], " differs from the required character or Id"))
	}

	prefix <- prefix@name

	if (! ("schema" %in% names (prefix))) {
		stop (paste0 ("Argument prefix must have a schema attribute"))
	}

	if ("table" %in% names (prefix)) {
		stop (paste0 ("Argument prefix cannot have a table attribute"))
	}

	sSchemaName <- prefix [["schema"]]

	sSQL <- DBI::SQL (paste0 (
		"select DatabaseName, TableName",
		" from DBC.TablesV",
		" where TableKind in ('O', 'T', 'V')",
		" and DatabaseName (not casespecific) = ", DBI::dbQuoteLiteral (conn, sSchemaName), " (not casespecific)"
	))

	if (conn@m_bDebugLog) {
		cat (paste0 ("dbListObjects ", sSQL, "\n"))
	}

	df <- DBI::dbGetQuery (conn, sSQL)

	if (ncol (df) == 0) {
		return (data.frame (table = I (list ()), is_prefix = logical (), stringsAsFactors = FALSE)) # return zero rows
	}

	listQualifiedTables <- list ()
	for (nRow in seq_len (nrow (df))) {
		listQualifiedTables [[nRow]] <- DBI::Id (schema = df [nRow, 1], table = df [nRow, 2])
	}

	return (data.frame (table = I (listQualifiedTables), is_prefix = FALSE, stringsAsFactors = FALSE))

}) # end method dbListObjects

# dbListResults - deprecated method not implemented

#' Obtain the list of tables and views in the current database
#' `dbListTables(conn, ...)`
#' @param conn A TeradataConnection object
#' @return A character vector of all table names and view names in the current database
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbListTables", "TeradataConnection", function (conn, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbListTables ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbListTables ", conn, "\n")))
	}

	sSQL <- DBI::SQL ("select TableName from DBC.TablesV where DatabaseName (not casespecific) = database (not casespecific) and TableKind in ('O','T','V') order by 1")

	if (conn@m_bDebugLog) {
		cat (paste0 ("dbListTables ", sSQL, "\n"))
	}

	df <- DBI::dbGetQuery (conn, sSQL)

	if (ncol (df) > 0) {
		return (df [, 1]) # return the single result set column as a character vector
	} else {
		return (character ()) # return zero-length character vector
	}
}) # end method dbListTables

# dbQuoteIdentifier - use superclass implementation

# dbQuoteString - use superclass implementation

# dbReadTable - use superclass implementation

#' Drop a table
#' `dbRemoveTable(conn, name, ...)`
#' @param conn A TeradataConnection object
#' @param name A character string specifying a table name
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbRemoveTable", signature ("TeradataConnection", "character"), function (conn, name, fail_if_missing = TRUE, ...) {

	# Optional argument fail_if_missing appears before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbRemoveTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbRemoveTable ", conn, "\n")))
	}

	dropTable (conn, name, fail_if_missing)

	invisible (TRUE)

}) # end method dbRemoveTable

#' @export
#' @rdname TeradataConnection-class
setMethod ("dbRemoveTable", signature ("TeradataConnection", "Id"), function (conn, name, fail_if_missing = TRUE, ...) {

	# Optional argument fail_if_missing appears before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbRemoveTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbRemoveTable ", conn, "\n")))
	}

	dropTable (conn, name, fail_if_missing)

	invisible (TRUE)

}) # end method dbRemoveTable

dropTable <- function (conn, name, fail_if_missing) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dropTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dropTable ", conn, "\n")))
	}

	normalizeTableName (conn, name) # for validation

	if (fail_if_missing || DBI::dbExistsTable (conn, name)) {

		sSQL <- DBI::SQL (paste0 ("drop table ", DBI::dbQuoteIdentifier (conn, name)))

		if (conn@m_bDebugLog) {
			cat (paste0 ("dropTable ", sSQL, "\n"))
		}

		DBI::dbExecute (conn, sSQL)

	} # end if

	invisible (TRUE)

} # end dropTable

#' Rollback the current transaction
#' `dbRollback(conn, ...)`
#' @param conn A TeradataConnection object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbRollback", "TeradataConnection", function (conn, ...) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbRollback ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbRollback ", conn, "\n")))
	}

	DBI::dbExecute (conn, "{fn teradata_rollback}{fn teradata_autocommit_on}")
	invisible (TRUE)

}) # end method dbRollback

#' Prepare or execute a query
#' `dbSendQuery(conn, statement, ...)`
#' @param conn A TeradataConnection object
#' @param statement A character string containing the SQL request text
#' @return A TeradataResult object
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbSendQuery", signature ("TeradataConnection", "character"), function (conn, statement, params = NULL, immediate = NA, ...) {

	# Older versions of DBI sometimes specified the argument name as param instead of params:
	#  https://github.com/r-dbi/DBI/commit/b3c7158e6a0d5d7074865d32fc9519a950effc76#diff-0e4e2142b6f1dc502f427b009aca4d60
	# Because of that, we need to accommodate partial matching for the params argument.
	# Partial matching is disabled for arguments after dots:
	#  https://stackoverflow.com/questions/25513535/partial-matching-confusion-when-arguments-passed-through-dots
	# Therefore, params must appear in the argument list before the dots.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbSendQuery ", conn, " immediate=", immediate, " ", statement, "\n"))
		on.exit (cat (paste0 ("< leave dbSendQuery ", conn, " immediate=", immediate, " ", statement, "\n")))
	}

	if (conn@m_bDebugLog) {
		cat ("dbSendQuery statement begin:\n")
		cat (paste0 (statement, "\n"))
		cat ("dbSendQuery params begin:\n")
		print (params)
		cat ("dbSendQuery params end\n")
	}

	res <- constructTeradataResult (conn, statement)

	if (is.na (immediate)) {
		immediate <- conn@m_bImmediate
	}

	if (! is.null (params) || immediate) {
		DBI::dbBind (res, params)
	}

	return (res)

}) # end method dbSendQuery

#' Prepare or execute a SQL request
#' `dbSendStatement(conn, statement, ...)`
#' @param conn A TeradataConnection object
#' @param statement A character string containing the SQL request text
#' @return A TeradataResult object
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbSendStatement", signature ("TeradataConnection", "character"), function (conn, statement, params = NULL, immediate = NA, ...) {

	# Optional arguments params and immediate appear before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbSendStatement ", conn, " immediate=", immediate, " ", statement, "\n"))
		on.exit (cat (paste0 ("< leave dbSendStatement ", conn, " immediate=", immediate, " ", statement, "\n")))
	}

	return (DBI::dbSendQuery (conn, statement, params = params, immediate = immediate))

}) # end method dbSendStatement

# dbWithTransaction - use superclass implementation

#' Copy data frame to table
#' `dbWriteTable(conn, name, value, ...)`
#' @param conn A TeradataConnection object
#' @param name A character string specifying a table name
#' @param value A data frame
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataConnection-class
setMethod ("dbWriteTable", signature ("TeradataConnection", "character"), function (conn, name, value,
	row.names = FALSE, overwrite = FALSE, append = FALSE, field.types = NULL, temporary = FALSE, ...) {

	# Optional arguments row.names (and others) appear before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbWriteTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbWriteTable ", conn, "\n")))
	}

	writeTable (conn, name, value, row.names, overwrite, append, field.types, temporary)

	invisible (TRUE)

}) # end method dbWriteTable

#' @export
#' @rdname TeradataConnection-class
setMethod ("dbWriteTable", signature ("TeradataConnection", "Id"), function (conn, name, value,
	row.names = FALSE, overwrite = FALSE, append = FALSE, field.types = NULL, temporary = FALSE, ...) {

	# Optional arguments row.names (and others) appear before dots in order to accommodate partial argument matching.

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter dbWriteTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave dbWriteTable ", conn, "\n")))
	}

	writeTable (conn, name, value, row.names, overwrite, append, field.types, temporary)

	invisible (TRUE)

}) # end method dbWriteTable

writeTable <- function (conn, name, value, row.names, overwrite, append, field.types, temporary) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter writeTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave writeTable ", conn, "\n")))
	}

	normalizeTableName (conn, name) # for validation

	if (! is.data.frame (value)) {
		value <- as.data.frame (value, stringsAsFactors = FALSE) # convert list to data.frame which validates consistent column counts
	}

	if (is.null (row.names)) {
		row.names <- FALSE # the default
	}

	if (! is.logical (row.names) && ! is.character (row.names))  {
		stop (paste0 ("Argument row.names class ", class (row.names) [[1]], " differs from the required logical or string"))
	}

	if (length (row.names) != 1) {
		stop (paste0 ("Argument row.names length ", length (row.names), " differs from the required length 1"))
	}

	if (! is.logical (overwrite)) {
		stop (paste0 ("Argument overwrite class ", class (overwrite) [[1]], " differs from the required logical"))
	}

	if (length (overwrite) != 1) {
		stop (paste0 ("Argument overwrite length ", length (overwrite), " differs from the required length 1"))
	}

	if (! is.logical (append)) {
		stop (paste0 ("Argument append class ", class (append) [[1]], " differs from the required logical"))
	}

	if (length (append) != 1) {
		stop (paste0 ("Argument append length ", length (append), " differs from the required length 1"))
	}

	if (! is.logical (temporary)) {
		stop (paste0 ("Argument temporary class ", class (temporary) [[1]], " differs from the required logical"))
	}

	if (length (temporary) != 1) {
		stop (paste0 ("Argument temporary length ", length (temporary), " differs from the required length 1"))
	}

	if (overwrite && append) {
		stop ("Mutually-exclusive arguments specified overwrite and append")
	}

	bExists <- DBI::dbExistsTable (conn, name)

	# From the documentation for dbWriteTable:
	# If the table exists, and both append and overwrite arguments are unset ... an error is raised

	if (bExists && ! append && ! overwrite) {
		stop (paste0 ("Table ", DBI::dbQuoteIdentifier (conn, name), " exists but neither append or overwrite were specified"))
	}

	# From the documentation for dbWriteTable:
	# If the overwrite argument is TRUE, an existing table of the same name will be overwritten.
	# This argument doesn't change behavior if the table does not exist yet.

	if (bExists && overwrite) {
		DBI::dbRemoveTable (conn, name)
		bExists <- FALSE
	}

	# From the documentation for dbCreateTable:
	# The row.names argument is not supported by this method. Process the values with sqlRownamesToColumn() before calling this method.

	value <- DBI::sqlRownamesToColumn (value, row.names)

	# From the documentation for dbWriteTable:
	# If the append argument is TRUE, the rows in an existing table are preserved, and the new data are appended.
	# If the table doesn't exist yet, it is created.

	if (! bExists) {

		types <- vapply (value, function (x) DBI::dbDataType (conn, x), character (1))

		if (! is.null (field.types)) { # if we have field.types

			if (is.null (names (field.types))) { # no names in field.types
				aoDestRange <- seq_along (types)
				aoSrcRange  <- seq_along (field.types)
			} else { # we have names in field.types
				aoDestRange <- names (types)
				aoSrcRange  <- names (field.types)
			}

			aoRange <- intersect (aoDestRange, aoSrcRange)
			types [aoRange] <- field.types [aoRange] # slice-wise assignment

		} # end if we have field.types

		DBI::dbCreateTable (conn, name, types, temporary = temporary)

	} # end if ! bExists

	DBI::dbAppendTable (conn, name, value)

	invisible (TRUE)

} # end writeTable

# sqlAppendTable - use superclass implementation

# sqlAppendTableTemplate - use superclass implementation

#' Compose SQL request to create a table
#' `sqlCreateTable(con, table, fields, ...)`
#' @param con A TeradataConnection object
#' @param table A character string specifying a table name
#' @param fields Either a character vector or a data frame
#'   A named character vector: Names are column names, values are types.
#'   A data frame: field types are generated using [dbDataType()].
#' @param row.names Either `TRUE`, `FALSE`, `NA` or a string.
#'   If `TRUE`, translate row names to a column named "row_names".
#'   If `FALSE`, never translate row names.
#'   If `NA`, translate row names only if they are a character vector.
#    If a string, translate row names to a column named by the specified string.
#' @param temporary If `TRUE`, compose a SQL request to create a volatile table.
#' @return A string containing the SQL request text
#' @export
#' @rdname TeradataConnection-class
setMethod ("sqlCreateTable", "TeradataConnection", function (con, table, fields, row.names = NA, temporary = FALSE, ...) {

	conn <- con

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter sqlCreateTable ", conn, "\n"))
		on.exit (cat (paste0 ("< leave sqlCreateTable ", conn, "\n")))
	}

	normalizeTableName (conn, table) # for validation

	table <- DBI::dbQuoteIdentifier (conn, table)

	if (is.data.frame (fields)) {
		fields <- DBI::sqlRownamesToColumn (fields, row.names)
		fields <- vapply (fields, function (x) DBI::dbDataType (conn, x), character (1))
	}

	field_names <- DBI::dbQuoteIdentifier (conn, names (fields))
	field_types <- unname (fields)
	fields <- paste0 (field_names, " ", field_types)

	sSQL <- DBI::SQL (paste0 (
		"CREATE ", if (temporary) "VOLATILE ", "TABLE ", table,
		" (", paste (fields, collapse = ", "), ")",
		if (temporary) " ON COMMIT PRESERVE ROWS"
		))

	if (conn@m_bDebugLog) {
		cat (paste0 ("sqlCreateTable ", sSQL, "\n"))
	}

	return (sSQL)

}) # end method sqlCreateTable

# sqlData - use superclass implementation

# sqlInterpolate - use superclass implementation
