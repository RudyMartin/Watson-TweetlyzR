# Copyright 2018-2019 by Teradata Corporation. All Rights Reserved.
# TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#' Teradata SQL Driver for R
#'
#' @keywords internal
#' @import DBI
#' @import methods
#' @export
#' @rdname TeradataDriver-class
setClass ("TeradataDriver", contains = "DBIDriver")

envGlobals <- new.env (parent = emptyenv ()) # use an environment to hold global variables
envGlobals$bInitDone <- FALSE
envGlobals$sPackageName <- "teradatasql"
envGlobals$sLibBaseName <- "teradatasql"
envGlobals$sDynLoadPackageName <- envGlobals$sLibBaseName # Windows and Linux namespace for dynamic link function symbols
envGlobals$sDriverVersion <- as.character (packageVersion (envGlobals$sPackageName))

#' Instantiate the driver
#'
#' `teradatasql::TeradataDriver()`
#'
#' @return A TeradataDriver object
#' @export
#' @rdname TeradataDriver-class
TeradataDriver <- function () {

	if (! envGlobals$bInitDone) {

		if (Sys.info () ["sysname"] == "Windows") {
			sExtension <- "dll"
		} else if (Sys.info () ["sysname"] == "Darwin") {
			sExtension <- "dylib"
		} else {
			sExtension <- "so"
		}

		sLibFileName <- paste0 (envGlobals$sLibBaseName, ".", sExtension)
		sLibPathName <- system.file (sLibFileName, package = envGlobals$sPackageName)
		dyn.load (sLibPathName)

		# On Mac OS, the dynamic link function symbols are stored in a namespace that includes the file extension.
		# On Windows and Linux, the dynamic link function symbols are stored in a namespace that omits the file extension.
		if (is.loaded ("rgoParseParams", PACKAGE = sLibFileName)) {
			envGlobals$sDynLoadPackageName <- sLibFileName
		}

		envGlobals$bInitDone <- TRUE

	} # end if ! bInitDone

	return (new ("TeradataDriver"))

} # end TeradataDriver constructor

# dbCanConnect - use superclass implementation

#' Establish a connection to a database
#'
#' `dbConnect(drv, sConnectParams, ...)`
#'
#' @param drv A TeradataDriver object obtained from `teradatasql::TeradataDriver()`
#' @param jsonstr A character string in JSON format specifying the connection parameters
#' @return A TeradataConnection object
#' @export
#' @rdname TeradataDriver-class
setMethod ("dbConnect", "TeradataDriver", function (drv, jsonstr = NA, ...) {

	return (constructTeradataConnection (jsonstr, ...))

}) # end method dbConnect

isRawOrNA <- function (x) {

	return (is.raw (x) || is.na (x))

} # end isRawOrNA

isListOfRaw <- function (x) {

	bContainsRaw <- is.list (x) && any (sapply (x, is.raw))

	if (bContainsRaw) {
		abNotCompat <- ! sapply (x, isRawOrNA)
		if (any (abNotCompat)) {
			anNotCompat <- which (abNotCompat)
			stop (paste0 ("List elements with the following indexes are not compatible with raw: ", paste0 (anNotCompat, collapse = ", ")))
		}
	}

	return (bContainsRaw)

} # end isListOfRaw

intervalDtoS <- function (ao) { # format difftime vector as strings compatible with Teradata Database INTERVAL DAY TO SECOND

	adSeconds <- as.double (ao, units = "secs")
	asSign    <- ifelse (adSeconds < 0, "-", " ")
	adSeconds <- abs (adSeconds)

	adMinutes <- adSeconds %/% 60
	adHours   <- adMinutes %/% 60
	adDays    <- adHours   %/% 24

	adHours   <- adHours   %% 24
	adMinutes <- adMinutes %% 60
	adSeconds <- adSeconds %% 60

	return (sprintf ("%s%d %02d:%02d:%09.6f", asSign, adDays, adHours, adMinutes, adSeconds))

} # end intervalDtoS

getSQLTypeName <- function (x) {

	if (bit64::is.integer64 (x))           { return (        "BIGINT"                                        ) } # must be checked before is.numeric
	else if (inherits (x, "Date"))         { return (        "DATE"                                          ) } # there is no is.Date function
	else if (is.integer (x))               { return (        "INTEGER"                                       ) } # must be checked before is.numeric
	else if (is.numeric (x))               { return (        "FLOAT"                                         ) }
	else if (isListOfRaw (x))              { return (paste0 ("VARBYTE(", max (lengths (x)), ")")             ) }
	else if (hms::is.hms (x))              { return (        "TIME"                                          ) } # must be checked before difftime
	else if (inherits (x, "difftime"))     { return (paste0 ("VARCHAR(", max (nchar (intervalDtoS (x))), ")")) } # there is no is.difftime function
	else if (is.TimeWithTimeZone (x))      { return (        "TIME WITH TIME ZONE"                           ) }
	else if (is.Timestamp (x))             { return (        "TIMESTAMP"                                     ) }
	else if (is.TimestampWithTimeZone (x)) { return (        "TIMESTAMP WITH TIME ZONE"                      ) }
	else                                   { return (paste0 ("VARCHAR(", max (nchar (as.character (x))), ")")) } # default

} # end getSQLTypeName

#' Determine the SQL data type of an R object
#'
#' `dbDataType(dbObj, obj, ...)`
#'
#' @param dbObj A TeradataDriver object
#' @param obj An R object whose SQL type we want to determine
#' @return A string giving the SQL data type for the R object
#' @export
#' @rdname TeradataDriver-class
setMethod ("dbDataType", "TeradataDriver", function (dbObj, obj, ...) {

	return (getSQLTypeName (obj))

}) # end method dbDataType

# dbDriver - deprecated method not implemented

#' Obtain metadata from the driver
#' `dbGetInfo(dbObj, ...)`
#' @param dbObj A TeradataDriver object
#' @return A named list
#' @export
#' @rdname TeradataDriver-class
setMethod ("dbGetInfo", "TeradataDriver", function (dbObj, ...) {

	return (list (driver.version = envGlobals$sDriverVersion, client.version = envGlobals$sDriverVersion))

}) # end method dbGetInfo

# dbIsReadOnly - use superclass implementation

#' Determine whether the driver is usable
#' `dbIsValid(dbObj, ...)`
#' @param dbObj A TeradataDriver object
#' @return `TRUE` to indicate that the driver is usable
#' @export
#' @rdname TeradataDriver-class
setMethod ("dbIsValid", "TeradataDriver", function (dbObj, ...) {

	return (TRUE) # always usable

}) # end dbIsValid

# dbListConnections - deprecated method not implemented

# dbUnloadDriver - deprecated method not implemented

setGeneric (name = "getRandomBytes", def = function (drv, ...) {
	standardGeneric ("getRandomBytes")
})

#' Obtain random bytes from Go's crypto/rand.Rand
#' `getRandomBytes(drv, nByteCount, ...)`
#' @param drv A TeradataDriver object
#' @param nByteCount The number of random bytes to obtain
#' @return The specified number of random raw bytes
#' @export
#' @rdname TeradataDriver-class
setMethod ("getRandomBytes", "TeradataDriver", function (drv, nByteCount, ...) {

	result <- .C ("rgoGetRandomBytes",
		uLog             = bit64::as.integer64 (0),
		nRandomByteCount = as.integer (nByteCount),
		nErrorByteCount  = 0L,
		uErrorPtr        = bit64::as.integer64 (0),
		uRandomBytesPtr  = bit64::as.integer64 (0),
		PACKAGE          = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = bit64::as.integer64 (0),
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	resultRandom <- .C ("rgoFreeRawPointer",
		uLog       = bit64::as.integer64 (0),
		nByteCount = as.integer (nByteCount),
		uPtr       = result$uRandomBytesPtr,
		aby        = as.raw (seq (66, 66, length = nByteCount)), # prefill with 'B' characters
		PACKAGE    = envGlobals$sDynLoadPackageName
	)

	return (resultRandom$aby)

}) # end getRandomBytes
