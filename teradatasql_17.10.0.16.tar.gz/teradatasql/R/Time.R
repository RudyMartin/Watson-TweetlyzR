# Copyright 2019 by Teradata Corporation. All Rights Reserved.
# TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

parseTimeValue <- function (asInput, sClassName) {

	if (! is.character (asInput)) {
		stop (paste0 ("parse ", sClassName, " requires character input but was supplied with wrong class: ", paste0 (class (asInput), collapse = " ")))
	}

	bProcessDate     <- startsWith (sClassName, "Timestamp")
	bProcessTimeZone <- endsWith   (sClassName, "WithTimeZone")

	sPattern <- paste0 (
		"^",
		ifelse (bProcessDate, "\\d{4}-\\d{2}-\\d{2} ", ""),
		"\\d{2}:\\d{2}:\\d{2}(\\.\\d{1,6})?",
		ifelse (bProcessTimeZone, "[-+]\\d{2}:\\d{2}", ""),
		"$")

	abMatches    <- grepl (sPattern, asInput, perl = TRUE)
	abMismatches <- ! is.na (asInput) & ! abMatches # identify the non-NA mismatches
	anMismatches <- which (abMismatches) # indexes of the non-NA mismatches
	if (length (anMismatches) > 0) {
		stop (paste0 ("Strings with the following indexes do not match the ", sClassName, " format: ", paste0 (anMismatches, collapse = ", ")))
	}

	if (bProcessTimeZone) {

		anLengths  <- nchar (asInput)

		asTzMin    <- substr (asInput, anLengths - 1, anLengths)
		asTzHour   <- substr (asInput, anLengths - 4, anLengths - 3)
		asSign     <- substr (asInput, anLengths - 5, anLengths - 5)
		asInput    <- substr (asInput, 1            , anLengths - 6) # remove the time zone suffixes from the input strings

		anTzMin    <- as.integer (asTzMin)
		anTzHour   <- as.integer (asTzHour)
		anSign     <- ifelse (asSign == "+", 1L, -1L)
		anGmtOff   <- anSign * ((anTzHour * 60L) + anTzMin) * 60L # signed offset from GMT in seconds

	} # end if bProcessTimeZone

	sFormat      <- paste0 (ifelse (bProcessDate, "%Y-%m-%d ", ""), "%H:%M:%OS")

	ats          <- strptime (asInput, sFormat, tz = "GMT")

	attr (ats, "tzone") <- NULL # strip the time zone attribute

	if (! bProcessDate) {
		ats$year   <- ifelse (is.na (asInput), NA_integer_, 0L) # Year 0000 is not a valid year for the Teradata Database
		ats$mon    <- ifelse (is.na (asInput), NA_integer_, 0L) # Month 0 = January
		ats$mday   <- ifelse (is.na (asInput), NA_integer_, 1L) # First day of the month
	}

	if (bProcessTimeZone) {
		# The zone and gmtoff names must be added in the following order per the R documentation
		ats$zone   <- rep ("", length (asInput))
		ats$gmtoff <- anGmtOff
	}

	class (ats)  <- c (sClassName, class (ats))

	return (ats)

} # end parseTimeValue

#' Create a TimeWithTimeZone
#'
#' `teradatasql::TimeWithTimeZone(asInput)`
#'
#' @return A TimeWithTimeZone object
#' @export
#' @rdname TimeWithTimeZone-class
TimeWithTimeZone <- function (asInput) { # constructor

	return (parseTimeValue (asInput, "TimeWithTimeZone"))

} # end TimeWithTimeZone constructor

#' Create a Timestamp
#'
#' `teradatasql::Timestamp(asInput)`
#'
#' @return A Timestamp object
#' @export
#' @rdname Timestamp-class
Timestamp <- function (asInput) { # constructor

	return (parseTimeValue (asInput, "Timestamp"))

} # end Timestamp constructor

#' Create a TimestampWithTimeZone
#'
#' `teradatasql::TimestampWithTimeZone(asInput)`
#'
#' @return A TimestampWithTimeZone object
#' @export
#' @rdname TimestampWithTimeZone-class
TimestampWithTimeZone <- function (asInput) { # constructor

	return (parseTimeValue (asInput, "TimestampWithTimeZone"))

} # end TimestampWithTimeZone constructor

hasTimeZone <- function (x) {

	return (inherits (x, "POSIXlt") && "gmtoff" %in% names (unclass (x)))

} # end hasTimeZone

#' Identify a TimeWithTimeZone value
#'
#' `is.TimeWithTimeZone(x)`
#'
#' @return A logical
#' @export
#' @rdname TimeWithTimeZone-class
is.TimeWithTimeZone <- function (x) {

	return (inherits (x, "TimeWithTimeZone"))

} # end is.TimeWithTimeZone

#' Identify a Timestamp value
#'
#' `is.Timestamp(x)`
#'
#' @return A logical
#' @export
#' @rdname Timestamp-class
is.Timestamp <- function (x) {

	return (inherits (x, "POSIXt") && ! is.TimeWithTimeZone (x) && ! hasTimeZone (x))

} # end is.Timestamp

#' Identify a TimestampWithTimeZone value
#'
#' `is.TimestampWithTimeZone(x)`
#'
#' @return A logical
#' @export
#' @rdname TimestampWithTimeZone-class
is.TimestampWithTimeZone <- function (x) {

	return (inherits (x, "POSIXt") && ! is.TimeWithTimeZone (x) && hasTimeZone (x))

} # end is.TimestampWithTimeZone

# The paste0 function converts NA to "NA" so an alternative is needed to produce NA when either value is NA.
naPreservingConcat <- function (as1, as2) {

	return (ifelse (is.na (as1) | is.na (as2), NA_character_, paste0 (as1, as2))) # recycles arguments with mismatched lengths

} # end naPreservingConcat

formatTimeValue <- function (x, sExpectedClass) {

	if (! inherits (x, sExpectedClass)) {
		stop (paste0 ("format requires class ", sExpectedClass, " but was supplied with wrong class: ", paste0 (class (x), collapse = " ")))
	}

	ats           <- x
	bHasTimeZone  <- hasTimeZone (ats)

	if (bHasTimeZone) {
		anGmtOff    <- ats$gmtoff
		asSign      <- ifelse (anGmtOff < 0L, "-", "+")
		anTzHour    <- abs (anGmtOff) %/% 3600L
		anTzMin     <- (abs (anGmtOff) %% 3600L) %/% 60L
		asTimeZone  <- sprintf ("%s%02d:%02d", asSign, anTzHour, anTzMin)
	} else {
		asTimeZone  <- "" # rely on argument recycling when composing asOutput below
	}

	if (inherits (ats, "POSIXct")) {
		ats         <- as.POSIXlt (ats)
	}

	bIncludeDate  <- ! is.TimeWithTimeZone (ats)
	adSecs        <- ats$sec
	abHasFracSecs <- ifelse (is.na (adSecs), FALSE, (adSecs %% 1) != 0) # treat NA values as not having fractional seconds
	bHasFracSecs  <- any (abHasFracSecs) # format entire column with fractional seconds if any column values have fractional seconds
	sFormat       <- paste0 (ifelse (bIncludeDate, "%Y-%m-%d ", ""), "%H:%M:", ifelse (bHasFracSecs, "%OS6", "%S"))
	asOutput      <- naPreservingConcat (format.POSIXlt (ats, sFormat), asTimeZone)

	return (asOutput)

} # end formatTimeValue

#' Format a TimeWithTimeZone as a string
#'
#' `format(x)`
#'
#' @param x A TimeWithTimeZone
#' @return A character vector
#' @export
#' @rdname TimeWithTimeZone-class
format.TimeWithTimeZone <- function (x, ...) {

	return (formatTimeValue (x, "TimeWithTimeZone"))

} # end method format

#' Format a Timestamp as a string
#'
#' `format(x)`
#'
#' @param x A Timestamp
#' @return A character vector
#' @export
#' @rdname Timestamp-class
format.Timestamp <- function (x, ...) {

	return (formatTimeValue (x, "Timestamp"))

} # end method format

#' Format a TimestampWithTimeZone as a string
#'
#' `format(x)`
#'
#' @param x A TimestampWithTimeZone
#' @return A character vector
#' @export
#' @rdname TimestampWithTimeZone-class
format.TimestampWithTimeZone <- function (x, ...) {

	return (formatTimeValue (x, "TimestampWithTimeZone"))

} # end method format
