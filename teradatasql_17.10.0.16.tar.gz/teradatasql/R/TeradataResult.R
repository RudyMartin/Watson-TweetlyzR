# Copyright 2018-2019 by Teradata Corporation. All Rights Reserved.
# TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

#' TeradataResult class
#'
#' @keywords internal
#' @import bit64
#' @import DBI
#' @import methods
#' @export
#' @rdname TeradataResult-class
setClass ("TeradataResult", contains = "DBIResult", slots = list (
	m_con         = "TeradataConnection",
	m_sOperation  = "character", # used by dbGetStatement
	m_envMutable  = "environment"
))

setMethod ("as.character", "TeradataResult", function (x, ...) {

	return (paste0 ("TeradataResult uConnHandle=", x@m_con@m_uConnHandle, " uRowsHandle=", x@m_envMutable$uRowsHandle, " bCleared=", x@m_envMutable$bCleared))

}) # end method as.character

constructTeradataResult <- function (conn, sOperation) {

	if (conn@m_bTraceLog) {
		cat (paste0 ("> enter TeradataResult ", conn, "\n"))
		on.exit (cat (paste0 ("< leave TeradataResult ", conn, "\n")))
	}

	res <- new ("TeradataResult",
		m_con        = conn,
		m_sOperation = sOperation,
		m_envMutable = new.env (parent = emptyenv ()) # use an environment to hold mutable instance variables
	)

	res@m_envMutable$uRowsHandle <- NA # must initialize because of reference by as.character
	res@m_envMutable$bCleared <- FALSE # must initialize because of reference by as.character

	if (conn@m_bDebugLog) {
		cat (paste0 ("TeradataResult returning ", res, "\n"))
	}

	return (res)

} # end constructTeradataResult

stopIfCleared <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter stopIfCleared ", res, "\n"))
		on.exit (cat (paste0 ("< leave stopIfCleared ", res, "\n")))
	}

	if (res@m_envMutable$bCleared) {
		stop ("TeradataResult is closed")
	}

	invisible (TRUE)

} # end stopIfCleared

integer64ToRaw <- function (n) {

	class (n) <- "numeric"
	return (writeBin (n, raw (), endian = "big"))

} # end integer64ToRaw

rawToInteger64 <- function (aby) {

	d <- readBin (aby, double (), endian = "big")
	class (d) <- "integer64"
	return (d)

} # end rawToInteger64

# Serialized data value type codes:
# B=bytes
# D=double (64-bit double)
# F=false (bool)
# I=integer (32-bit integer)
# L=long (64-bit integer)
# M=number
# N=null
# S=string (UTF8-encoded)
# T=true (bool)
# U=date
# V=time
# W=time with time zone
# X=timestamp
# Y=timestamp with time zone
# Z=terminator

serializeCharacterValue <- function (sTypeCode, s) {

	aby <- charToRaw (s)
	return (c (charToRaw (sTypeCode), integer64ToRaw (bit64::as.integer64 (length (aby))), aby))

} # end serializeCharacterValue

deserializeCharacterValue <- function (sExpectedTypeCode, aby, i, envByRef) {

	sActualTypeCode <- rawToChar (aby [i])

	if (sActualTypeCode == sExpectedTypeCode) {
		i <- i + 1

		nByteCount <- as.integer (rawToInteger64 (aby [i : (i + 7)]))
		i <- i + 8

		if (nByteCount == 0) {
			sValue <- ""
		} else {
			sValue <- rawToChar (aby [i : (i + nByteCount - 1)])
		}

		i <- i + nByteCount

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- sValue
		}

		return (i)

	} else if (sActualTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type ", sExpectedTypeCode, "/N but got ", sActualTypeCode, " at byte offset ", i))
	}
} # end deserializeCharacterValue

serializeBool <- function (b) {

	return (charToRaw (ifelse (b, "T", "F")))

} # end serializeBool

deserializeBool <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode %in% c ("T", "F")) { # T=true, F=false

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- sTypeCode == "T"
		}

		return (i + 1)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type T/F/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeBool

serializeBytes <- function (aby) {

	return (c (charToRaw ("B"), integer64ToRaw (bit64::as.integer64 (length (aby))), aby))

} # end serializeBytes

deserializeBytes <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "B") { # B=bytes
		i <- i + 1

		nByteCount <- as.integer (rawToInteger64 (aby [i : (i + 7)]))
		i <- i + 8

		abyValue <- aby [i : (i + nByteCount - 1)]
		i <- i + nByteCount

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- abyValue
		}

		return (i)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type B/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeBytes

serializeDate <- function (da) {

	return (serializeCharacterValue ("U", as.character (da)))

} # end serializeDate

deserializeDate <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("U", aby, i, envByRef))

} # end deserializeDate

serializeDouble <- function (d) {

	return (c (charToRaw ("D"), writeBin (d, raw (), endian = "big")))

} # end serializeDouble

deserializeDouble <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "D") { # D=double
		i <- i + 1

		dValue <- readBin (aby [i : (i + 7)], double (), endian = "big")
		i <- i + 8

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- dValue
		}

		return (i)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type D/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeDouble

serializeInt <- function (n) {

	return (c (charToRaw ("I"), writeBin (n, raw (), endian = "big")))

} # end serializeInt

deserializeInt <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "I") { # I=integer
		i <- i + 1

		nValue <- readBin (aby [i : (i + 3)], integer (), endian = "big")
		i <- i + 4

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- nValue
		}

		return (i)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type I/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeInt

serializeLong <- function (n) {

	return (c (charToRaw ("L"), integer64ToRaw (n)))

} # end serializeLong

deserializeLong <- function (aby, i, envByRef, convertToDouble = FALSE) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "L") { # L=long
		i <- i + 1

		nValue <- rawToInteger64 (aby [i : (i + 7)])
		i <- i + 8

		if (! is.null (envByRef)) {

			if (convertToDouble) { nValue <- as.numeric (nValue) }

			envByRef$row [[length (envByRef$row) + 1]] <- nValue
		}

		return (i)

	} else if (sTypeCode == "N") { # N=null
		return (deserializeNull (aby, i, envByRef))

	} else {
		stop (paste0 ("Expected column type L/N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeLong

serializeNull <- function () {

		return (charToRaw ("N"))

} # end serializeNull

deserializeNull <- function (aby, i, envByRef) {

	sTypeCode <- rawToChar (aby [i])

	if (sTypeCode == "N") { # N=null

		if (! is.null (envByRef)) {
			envByRef$row [[length (envByRef$row) + 1]] <- NA
		}

		return (i + 1)

	} else {
		stop (paste0 ("Expected column type N but got ", sTypeCode, " at byte offset ", i))
	}
} # end deserializeNull

serializeNumber <- function (dec) {

	return (serializeCharacterValue ("M", format (dec, scientific = FALSE))) # avoid exponential notation

} # end serializeNumber

deserializeNumber <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("M", aby, i, envByRef))

} # end deserializeNumber

serializeString <- function (s) {

	return (serializeCharacterValue ("S", s))

} # end serializeString

deserializeString <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("S", aby, i, envByRef))

} # end deserializeString

serializeTime <- function (ti) { # ti will be hms

	return (serializeCharacterValue ("V", as.character (ti)))

} # end serializeTime

deserializeTime <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("V", aby, i, envByRef))

} # end deserializeTime

serializeTimeWithTimeZone <- function (ti) { # ti will be TimeWithTimeZone

	return (serializeCharacterValue ("W", as.character (ti)))

} # end serializeTimeWithTimeZone

deserializeTimeWithTimeZone <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("W", aby, i, envByRef))

} # end deserializeTimeWithTimeZone

serializeTimestamp <- function (ts) { # ts will be POSIXct or POSIXlt

	return (serializeCharacterValue ("X", formatTimeValue (ts, "POSIXt")))

} # end serializeTimestamp

deserializeTimestamp <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("X", aby, i, envByRef))

} # end deserializeTimestamp

serializeTimestampWithTimeZone <- function (ts) { # ts will be POSIXlt

	return (serializeCharacterValue ("Y", formatTimeValue (ts, "POSIXlt")))

} # end serializeTimestampWithTimeZone

deserializeTimestampWithTimeZone <- function (aby, i, envByRef) {

	return (deserializeCharacterValue ("Y", aby, i, envByRef))

} # end deserializeTimestampWithTimeZone

appendRowToColumnwiseLists <- function (envByRef) {

	for (nColumn in seq_along (envByRef$row)) {

		if (length (envByRef$listColumnwiseLists) < nColumn) {
			envByRef$listColumnwiseLists [[nColumn]] <- list () # construct a list of lists for better append performance
		}

		nRow <- length (envByRef$listColumnwiseLists [[nColumn]]) + 1

		envByRef$listColumnwiseLists [[nColumn]] [[nRow]] <- envByRef$row [[nColumn]] # append each column value to its respective column

	} # end for nColumn

	invisible (TRUE)

} # end appendRowToColumnwiseLists

dataFrameFromColumnwiseLists <- function (listColumnwiseLists, asColumnNames) {

	if (length (listColumnwiseLists) > 0 && length (asColumnNames) != length (listColumnwiseLists)) {
		stop (paste0 ("Column name count ", length (asColumnNames), " differs from column count ", length (listColumnwiseLists)))
	}

	listTemp <- list ()

	for (nColumn in seq_along (listColumnwiseLists)) {

		listColumnValues <- listColumnwiseLists [[nColumn]]

		# raw values are vectors of byte, and we must avoid applying c to raw values, because that will concatenate the values together

		if (isListOfRaw (listColumnValues)) {
			listTemp [[nColumn]] <- I (listColumnValues) # use I to prevent unlisting
		} else {
			listTemp [[nColumn]] <- do.call (c, listColumnValues) # convert list to vector
		}
	} # end for nColumn

	df <- as.data.frame (listTemp, stringsAsFactors = FALSE)

	if (ncol (df) > 0) {
		colnames (df) <- asColumnNames
	}

	return (df)

} # end dataFrameFromColumnwiseLists

obtainRows <- function (res, bPrepare, params) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter obtainRows ", res, "\n"))
		on.exit (cat (paste0 ("< leave obtainRows ", res, "\n")))
	}

	stopIfCleared (res)

	closeRows (res)

	sRequestText <- paste0 (ifelse (bPrepare, "{fn teradata_rpo(S)}", ""), res@m_sOperation)

	if (is.null (params)) {
		params <- data.frame () # convert NULL params to zero-column zero-row data.frame
	}

	if (! is.data.frame (params) && is.list (params)) {
		params <- as.data.frame (params, stringsAsFactors = FALSE) # convert list to data.frame which validates consistent column counts
	}

	if (! is.data.frame (params)) {
		stop (paste0 ("Argument params class ", class (params) [[1]], " differs from the required data.frame or list"))
	}

	if (res@m_con@m_bDebugLog) {
		cat ("obtainRows sRequestText begin:\n")
		cat (paste0 (sRequestText, "\n"))
		cat ("obtainRows params begin:\n")
		print (params)
		cat (paste0 ("obtainRows params ncol=", ncol (params), " nrow=", nrow (params), "\n"))
	}

	aaoColumns <- list ()
	for (nColumn in seq_len (ncol (params))) {
		aaoColumns [[length (aaoColumns) + 1]] <- params [, nColumn]
	}

	anColumnType <- integer (0)
	if (nrow (params) > 0) {

		for (nColumn in seq_len (ncol (params))) {

			oValue <- aaoColumns [[nColumn]] [1] # examine first row values to determine data types

			if (bit64::is.integer64 (oValue)) { # must be checked before is.numeric
				anColumnType <- c (anColumnType, 1L)
			} else if (inherits (oValue, "Date")) { # there is no is.Date function
				anColumnType <- c (anColumnType, 2L)
			} else if (is.integer (oValue)) { # must be checked before is.numeric
				anColumnType <- c (anColumnType, 3L)
			} else if (is.numeric (oValue)) {
				anColumnType <- c (anColumnType, 4L)
			} else if (isListOfRaw (aaoColumns [[nColumn]])) { # examine entire column not just first row
				anColumnType <- c (anColumnType, 5L)
			} else if (hms::is.hms (oValue)) { # must be checked before difftime
				anColumnType <- c (anColumnType, 6L)
			} else if (inherits (oValue, "difftime")) { # there is no is.difftime function
				anColumnType <- c (anColumnType, 7L)
			} else if (is.TimeWithTimeZone (oValue)) {
				anColumnType <- c (anColumnType, 8L)
			} else if (is.Timestamp (oValue)) {
				anColumnType <- c (anColumnType, 9L)
			} else if (is.TimestampWithTimeZone (oValue)) {
				anColumnType <- c (anColumnType, 10L)
			} else { # convert everything else to its character representation
				anColumnType <- c (anColumnType, 11L)
			}
		} # end for nColumn
	} # end if nrow

	conBindValues <- rawConnection (raw (0), "wb")
	tryCatch ({
		for (nRow in seq_len (nrow (params))) {

			for (nColumn in seq_len (ncol (params))) {

				oValue <- aaoColumns [[nColumn]] [nRow]
				nColumnType <- anColumnType [[nColumn]]

				if (res@m_con@m_bDebugLog) {
					cat (paste0 ("obtainRows params[", nRow, ",", nColumn, "] begin:\n"))
					print (oValue)
					cat (paste0 ("obtainRows params[", nRow, ",", nColumn, "] end\n"))
				}

				if (nColumnType == 1L) { # integer64

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeLong (oValue), conBindValues)
					}
				} else if (nColumnType == 2L) { # Date

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeDate (oValue), conBindValues)
					}
				} else if (nColumnType == 3L) { # integer

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeInt (oValue), conBindValues)
					}
				} else if (nColumnType == 4L) { # double

					if (is.na (oValue) && ! is.nan (oValue)) { # is.na returns TRUE for NaN
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeDouble (oValue), conBindValues)
					}
				} else if (nColumnType == 5L) { # list of raw

					oValue <- oValue [[1]]
					if (is.raw (oValue)) {
						writeBin (serializeBytes (oValue), conBindValues)
					} else {
						writeBin (serializeNull (), conBindValues)
					}
				} else if (nColumnType == 6L) { # hms

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeTime (oValue), conBindValues) # oValue will be hms
					}
				} else if (nColumnType == 7L) { # difftime

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						oValue <- intervalDtoS (oValue)
						writeBin (serializeString (oValue), conBindValues)
					}
				} else if (nColumnType == 8L) { # TimeWithTimeZone

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeTimeWithTimeZone (oValue), conBindValues) # oValue will be TimeWithTimeZone
					}
				} else if (nColumnType == 9L) { # Timestamp

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeTimestamp (oValue), conBindValues) # oValue will be POSIXct or POSIXlt
					}
				} else if (nColumnType == 10L) { # TimestampWithTimeZone

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						writeBin (serializeTimestampWithTimeZone (oValue), conBindValues) # oValue will be POSIXlt
					}
				} else { # nColumnType == 11L

					if (is.na (oValue)) {
						writeBin (serializeNull (), conBindValues)
					} else {
						oValue <- as.character (oValue) # convert everything else to its character representation
						writeBin (serializeString (oValue), conBindValues)
					}
				}
			} # end for nColumn

			writeChar ("Z", conBindValues, eos = NULL) # terminator

		} # end for nRow

		writeChar ("Z", conBindValues, eos = NULL) # terminator

		abyBindValues <- rawConnectionValue (conBindValues)

	}, finally = {

		close (conBindValues)

	}) # end finally

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainRows len=", length (abyBindValues), " abyBindValues=", paste0 (format (abyBindValues), collapse = " "), "\n"))
	}

	result <- .C ("rgoCreateRows",
		uLog                 = res@m_con@m_uLog,
		uConnHandle          = res@m_con@m_uConnHandle,
		sRequestText         = sRequestText,
		uBindValuesByteCount = bit64::as.integer64 (length (abyBindValues)),
		abyBindValues        = abyBindValues,
		nErrorByteCount      = 0L,
		uErrorPtr            = bit64::as.integer64 (0),
		uRowsHandle          = bit64::as.integer64 (0),
		PACKAGE              = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	res@m_envMutable$uRowsHandle <- result$uRowsHandle
	res@m_envMutable$uFetchedRowCount <- bit64::as.integer64 (0)
	res@m_envMutable$bCompleted <- FALSE

	obtainColumnMetaData (res)

	invisible (res)

} # end obtainRows

obtainColumnMetaData <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter obtainColumnMetaData ", res, "\n"))
		on.exit (cat (paste0 ("< leave obtainColumnMetaData ", res, "\n")))
	}

	result <- .C ("rgoResultMetaData",
		uLog                     = res@m_con@m_uLog,
		uRowsHandle              = res@m_envMutable$uRowsHandle,
		nErrorByteCount          = 0L,
		uErrorPtr                = bit64::as.integer64 (0),
		uActivityCount           = bit64::as.integer64 (0),
		nColumnMetaDataByteCount = 0L,
		uColumnMetaDataPtr       = bit64::as.integer64 (0),
		PACKAGE                  = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	res@m_envMutable$uActivityCount <- result$uActivityCount

	resultColumnMetaData <- .C ("rgoFreeRawPointer",
		uLog       = res@m_con@m_uLog,
		nByteCount = result$nColumnMetaDataByteCount,
		uPtr       = result$uColumnMetaDataPtr,
		aby        = as.raw (seq (66, 66, length = result$nColumnMetaDataByteCount)), # prefill with 'B' characters
		PACKAGE    = envGlobals$sDynLoadPackageName
	)

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainColumnMetaData resultColumnMetaData$aby = ", paste0 (format (resultColumnMetaData$aby), collapse = " "), "\n"))
	}

	resultPOSIXlt <- .C ("rgoResultPOSIXlt",
		uLog            = res@m_con@m_uLog,
		uRowsHandle     = res@m_envMutable$uRowsHandle,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		bResultPOSIXlt  = FALSE,
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (resultPOSIXlt$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = resultPOSIXlt$nErrorByteCount,
			uErrorPtr       = resultPOSIXlt$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = resultPOSIXlt$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	if (res@m_con@m_bDebugLog) {
		cat (paste0 ("obtainColumnMetaData resultPOSIXlt$bResultPOSIXlt = ", resultPOSIXlt$bResultPOSIXlt, "\n"))
	}

	envByRef <- new.env (parent = emptyenv ()) # use an environment for pass-by-reference
	envByRef$listColumnwiseLists <- list ()

	i <- 1
	while (rawToChar (resultColumnMetaData$aby [i]) != "Z") { # Z=terminator

		envByRef$row <- list ()

		# (1) Column name
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		# (2) Type name
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		# (3) Type code
		i <- deserializeString (resultColumnMetaData$aby, i, envByRef)

		if (envByRef$row [[length (envByRef$row)]] == "b") { # typeCode b=bytes
			envByRef$row [[length (envByRef$row)]] <- "raw"

		} else if (envByRef$row [[length (envByRef$row)]] == "d") { # typeCode d=double
			envByRef$row [[length (envByRef$row)]] <- "numeric"

		} else if (envByRef$row [[length (envByRef$row)]] == "i") { # typeCode i=integer (int32)
			envByRef$row [[length (envByRef$row)]] <- "integer"

		} else if (envByRef$row [[length (envByRef$row)]] == "l") { # typeCode l=long (int64)
			envByRef$row [[length (envByRef$row)]] <- "integer64"

		} else if (envByRef$row [[length (envByRef$row)]] == "m") { # typeCode m=number
			envByRef$row [[length (envByRef$row)]] <- "numeric"

		} else if (envByRef$row [[length (envByRef$row)]] == "s") { # typeCode s=string
			envByRef$row [[length (envByRef$row)]] <- "character"

		} else if (envByRef$row [[length (envByRef$row)]] == "u") { # typeCode u=date
			envByRef$row [[length (envByRef$row)]] <- "Date"

		} else if (envByRef$row [[length (envByRef$row)]] == "v") { # typeCode v=time
			envByRef$row [[length (envByRef$row)]] <- "hms"

		} else if (envByRef$row [[length (envByRef$row)]] == "w") { # typeCode w=time with time zone
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "TimeWithTimeZone", "character")

		} else if (envByRef$row [[length (envByRef$row)]] == "x") { # typeCode x=timestamp
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "Timestamp", "POSIXct")

		} else if (envByRef$row [[length (envByRef$row)]] == "y") { # typeCode y=timestamp with time zone
			envByRef$row [[length (envByRef$row)]] <- ifelse (resultPOSIXlt$bResultPOSIXlt, "TimestampWithTimeZone", "character")
		}

		# (4) Max byte count
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (5) Precision
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (6) Scale
		i <- deserializeLong (resultColumnMetaData$aby, i, envByRef, convertToDouble = TRUE)

		# (7) Nullable
		i <- deserializeBool (resultColumnMetaData$aby, i, envByRef)

		appendRowToColumnwiseLists (envByRef)

	} # end while

	res@m_envMutable$dfColumnMetaData <- dataFrameFromColumnwiseLists (envByRef$listColumnwiseLists, c ("name", "type", "Sclass", "len", "precision", "scale", "nullOK"))

	invisible (res)

} # end obtainColumnMetaData

#' Bind values to prepared statement parameter markers
#' `dbBind(res, params, ...)`
#' @param res A TeradataResult object
#' @param params Parameter values to bind
#' @return The TeradataResult invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("dbBind", "TeradataResult", function (res, params, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbBind ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbBind ", res, "\n")))
	}

	stopIfCleared (res)

	obtainRows (res, FALSE, params) # execute RPO=B unless overriden

	invisible (res)

}) # end method dbBind

#' Close the result
#' `dbClearResult(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("dbClearResult", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbClearResult ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbClearResult ", res, "\n")))
	}

	if (res@m_envMutable$bCleared) {
		warning ("TeradataResult is already cleared")
	} else {
		closeRows (res)
		res@m_envMutable$bCleared <- TRUE
	}

	invisible (TRUE)

}) # end method dbClearResult

closeRows <- function (res) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter closeRows ", res, "\n"))
		on.exit (cat (paste0 ("< leave closeRows ", res, "\n")))
	}

	bHasOpenRows <- ! is.na (res@m_envMutable$uRowsHandle)
	if (bHasOpenRows) {

		result <- .C ("rgoCloseRows",
			uLog            = res@m_con@m_uLog,
			uRowsHandle     = res@m_envMutable$uRowsHandle,
			nErrorByteCount = 0L,
			uErrorPtr       = bit64::as.integer64 (0),
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		if (result$nErrorByteCount > 0) {

			resultErr <- .C ("rgoFreeCharPointer",
				uLog            = res@m_con@m_uLog,
				nErrorByteCount = result$nErrorByteCount,
				uErrorPtr       = result$uErrorPtr,
				sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
				PACKAGE         = envGlobals$sDynLoadPackageName
			)

			stop (resultErr$sErrorMsg)

		} # end if nErrorByteCount > 0

		res@m_envMutable$uRowsHandle <- NA

	} # end if bHasOpenRows

	invisible (bHasOpenRows)

} # end closeRows

#' Obtain result column metadata
#' `dbColumnInfo(res, ...)`
#' @param res A TeradataResult object
#' @return A data frame with columns `name` (type `character`), `Sclass` (R data type), `type` (type `character`),
#'   `len` (type `integer`), precision (type `integer`), scale (type `integer`), nullOK (type `logical`).
#'   The data frame contains one row for each result column.
#' @export
#' @rdname TeradataResult-class
setMethod ("dbColumnInfo", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbColumnInfo ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbColumnInfo ", res, "\n")))
	}

	stopIfCleared (res)

	# Just-in-time prepare operation if the app requests column metadata before execution
	if (! ("dfColumnMetaData" %in% names (res@m_envMutable))) {

		obtainRows (res, TRUE, NULL) # prepare RPO=S
		closeRows (res)
	}

	return (res@m_envMutable$dfColumnMetaData)

}) # end method dbColumnInfo

stopIfNoBind <- function (res) {

	if (is.na (res@m_envMutable$uRowsHandle)) {
		stop ("Must call dbBind before dbFetch")
	}

	invisible (TRUE)

} # end stopIfNoBind

fetchRow <- function (res, envByRef) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter fetchRow ", res, "\n"))
		on.exit (cat (paste0 ("< leave fetchRow ", res, "\n")))
	}

	stopIfCleared (res)
	stopIfNoBind (res)

	result <- .C ("rgoFetchRow",
		uLog                   = res@m_con@m_uLog,
		uRowsHandle            = res@m_envMutable$uRowsHandle,
		nErrorByteCount        = 0L,
		uErrorPtr              = bit64::as.integer64 (0),
		nColumnValuesByteCount = 0L,
		uColumnValuesPtr       = bit64::as.integer64 (0),
		PACKAGE                = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	if (result$uColumnValuesPtr == 0) { # no more rows

		if (res@m_con@m_bDebugLog) {
			cat ("fetchRow returning FALSE to indicate no more rows\n")
		}

		res@m_envMutable$bCompleted <- TRUE
		return (FALSE) # indicate no more rows
	}

	row <- .C ("rgoFreeRawPointer",
		uLog                   = res@m_con@m_uLog,
		nColumnValuesByteCount = result$nColumnValuesByteCount,
		uColumnValuesPtr       = result$uColumnValuesPtr,
		abyColumnValues        = as.raw (seq (66, 66, length = result$nColumnValuesByteCount)), # prefill with 'B' characters
		PACKAGE                = envGlobals$sDynLoadPackageName
	)

	envByRef$row <- list ()
	i <- 1
	while (rawToChar (row$abyColumnValues [i]) != "Z") { # Z=terminator

		sTypeCode <- rawToChar (row$abyColumnValues [i])

		if (sTypeCode == "N") { # N=null
			iNew <- deserializeNull (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "B") { # B=bytes
			iNew <- deserializeBytes (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "D") { # D=double
			iNew <- deserializeDouble (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "I") { # I=integer
			iNew <- deserializeInt (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "L") { # L=long
			iNew <- deserializeLong (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "M") { # M=number
			iNew <- deserializeNumber (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "S") { # S=string
			iNew <- deserializeString (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "U") { # U=date
			iNew <- deserializeDate (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "V") { # V=time
			iNew <- deserializeTime (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "W") { # W=time with time zone
			iNew <- deserializeTimeWithTimeZone (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "X") { # X=timestamp
			iNew <- deserializeTimestamp (row$abyColumnValues, i, envByRef)

		} else if (sTypeCode == "Y") { # Y=timestamp with time zone
			iNew <- deserializeTimestampWithTimeZone (row$abyColumnValues, i, envByRef)

		} else {
			stop (paste0 ("Unrecognized column type ", sTypeCode, " at byte offset ", i))
		}

		if (res@m_con@m_bDebugLog) {
			oLast <- tail (envByRef$row, 1) [[1]]
			cat (paste0 ("fetchRow row[", length (envByRef$row), "] typeCode=", sTypeCode, " type=", typeof (oLast), " value=", paste0 (oLast, collapse = ""), "\n"))
		}

		i <- iNew

	} # end while

	res@m_envMutable$uFetchedRowCount <- res@m_envMutable$uFetchedRowCount + 1
	return (TRUE) # indicate row is available

} # end fetchRow

#' Fetch rows
#' `dbFetch(res, n = -1, ...)`
#' An attempt to fetch from a closed result set raises an error.
#' @param res A TeradataResult object
#' @param n Maximum number of rows to fetch. Specify n = -1 or n = Inf to fetch all remaining rows.
#'   If the n argument is not an atomic whole number greater or equal to -1 or Inf, an error is raised.
#' @return A data frame with columns and rows corresponding to result set columns and rows.
#'   If the SQL statement returned an empty result set, the data frame will have fully-typed columns but zero rows.
#'   If the SQL statement did not return a result set, the data frame will have zero columns and zero rows.
#'   The column types of the returned data frame depend on the data returned:
#'     integer for 32-bit integer values
#'     bit64::as.integer64() for 64-bit integer values
#'     numeric for numbers with a fractional component
#'     character for text
#'     raw for blobs
#'     as.Date() for dates
#'     hms::as_hms() for times
#'     as.POSIXct() for timestamps
#'     NA for SQL NULL values
#' @export
#' @rdname TeradataResult-class
setMethod ("dbFetch", "TeradataResult", function (res, n = -1, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbFetch ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbFetch ", res, "\n")))
	}

	stopIfCleared (res)
	stopIfNoBind (res)

	if (is.na (n) || ! is.numeric (n) || (n %% 1) != 0 || n < -1) {
		stop (paste0 ("Argument n must be a whole number -1 or greater: ", n))
	}

	nDesiredRowCount <- ifelse (n == Inf, -1L, as.integer (n))

	envByRef <- new.env (parent = emptyenv ()) # use an environment for pass-by-reference
	envByRef$listColumnwiseLists <- list ()

	nGatheredRowCount <- 0L
	while ((nDesiredRowCount < 0L || nGatheredRowCount < nDesiredRowCount) && fetchRow (res, envByRef)) {
		appendRowToColumnwiseLists (envByRef)
		nGatheredRowCount <- nGatheredRowCount + 1L
	}

	# The data.frame constructor mishandles a list containing integer64 values whose first element is a logical NA value.
	# RDBI-75 For an integer64 column, we must ensure that the list's first element is an integer64 value.

	for (nColumn in seq_along (envByRef$listColumnwiseLists)) {
		if (length (envByRef$listColumnwiseLists [[nColumn]]) > 0) {
			sColumnType <- res@m_envMutable$dfColumnMetaData$Sclass [[nColumn]]
			if (sColumnType == "integer64") {
				envByRef$listColumnwiseLists [[nColumn]] [[1]] <- bit64::as.integer64 (envByRef$listColumnwiseLists [[nColumn]] [[1]])
			}
		} # end if length
	} # end for nColumn

	df <- dataFrameFromColumnwiseLists (envByRef$listColumnwiseLists, res@m_envMutable$dfColumnMetaData$name)

	# The data.frame constructor mishandles POSIXlt values, so values derived from POSIXlt must
	# be composed and stored in the data.frame columns after the data.frame is constructed.

	# A column containing all NULL values will produce a logical vector containing all NA values,
	# and we must coerce the logical vector to the appropriate type of vector.

	# Also, the as_hms, TimeWithTimeZone, Timestamp, and TimestampWithTimeZone constructors do not accept
	# logical NA values, only NA_character_ values, so those column vectors must be coerced to character.

	for (nColumn in seq_len (ncol (df))) {

		sColumnType <- res@m_envMutable$dfColumnMetaData$Sclass [[nColumn]]

		if      (sColumnType == "character"            ) { df [[nColumn]] <- as.character                        (df [[nColumn]])  }
		else if (sColumnType == "numeric"              ) { df [[nColumn]] <- as.numeric                          (df [[nColumn]])  }
		else if (sColumnType == "integer"              ) { df [[nColumn]] <- as.integer                          (df [[nColumn]])  }
		else if (sColumnType == "integer64"            ) { df [[nColumn]] <- bit64::as.integer64                 (df [[nColumn]])  }
		else if (sColumnType == "Date"                 ) { df [[nColumn]] <- as.Date                             (df [[nColumn]])  }
		else if (sColumnType == "hms"                  ) { df [[nColumn]] <- hms::as_hms           (as.character (df [[nColumn]])) }
		else if (sColumnType == "POSIXct"              ) { df [[nColumn]] <- as.POSIXct            (as.character (df [[nColumn]]), tz = "GMT") }
		else if (sColumnType == "TimeWithTimeZone"     ) { df [[nColumn]] <- TimeWithTimeZone      (as.character (df [[nColumn]])) }
		else if (sColumnType == "Timestamp"            ) { df [[nColumn]] <- Timestamp             (as.character (df [[nColumn]])) }
		else if (sColumnType == "TimestampWithTimeZone") { df [[nColumn]] <- TimestampWithTimeZone (as.character (df [[nColumn]])) }

	} # end for

	return (df)

}) # end method dbFetch

# dbGetInfo - use superclass implementation

#' Obtain the number of rows fetched
#' `dbGetRowCount(res, ...)`
#' @param res A TeradataResult object
#' @return The number of rows fetched so far
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetRowCount", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetRowCount ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetRowCount ", res, "\n")))
	}

	stopIfCleared (res)

	nMaxValue <- 9007199254740991
	if (res@m_envMutable$uFetchedRowCount > nMaxValue) {

		warning (paste0 ("Actual row count ", res@m_envMutable$uFetchedRowCount, " exceeds the maximum numeric value ", nMaxValue))
		return (nMaxValue)
	}

	return (bit64::as.double.integer64 (res@m_envMutable$uFetchedRowCount))

}) # end method dbGetRowCount

#' Obtain the number of rows affected by the SQL statement
#' `dbGetRowsAffected(res, ...)`
#' @param res A TeradataResult object
#' @return The number of rows affected by the SQL statement
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetRowsAffected", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetRowsAffected ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetRowsAffected ", res, "\n")))
	}

	stopIfCleared (res)

	nMaxValue <- 9007199254740991
	if (res@m_envMutable$uActivityCount > nMaxValue) {

		warning (paste0 ("Actual row count ", res@m_envMutable$uActivityCount, " exceeds the maximum numeric value ", nMaxValue))
		return (nMaxValue)
	}

	return (bit64::as.double.integer64 (res@m_envMutable$uActivityCount))

}) # end method dbGetRowsAffected

#' Obtain the SQL request text
#' `dbGetStatement(res, ...)`
#' @param res A TeradataResult object
#' @return The SQL request text
#' @export
#' @rdname TeradataResult-class
setMethod ("dbGetStatement", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbGetStatement ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbGetStatement ", res, "\n")))
	}

	stopIfCleared (res)

	return (res@m_sOperation)

}) # end method dbGetStatement

#' Determine whether the entire result has been fetched
#' `dbHasCompleted(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` if all rows have been fetched, `FALSE` otherwise
#' @export
#' @rdname TeradataResult-class
setMethod ("dbHasCompleted", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbHasCompleted ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbHasCompleted ", res, "\n")))
	}

	stopIfCleared (res)

	return (res@m_envMutable$bCompleted)

}) # end method dbHasCompleted

# dbIsReadOnly - use superclass implementation

#' Determine whether the result is usable
#' `dbIsValid(dbObj, ...)`
#' @param dbObj A TeradataResult object
#' @return `TRUE` to indicate that the result is usable, `FALSE` otherwise
#' @export
#' @rdname TeradataResult-class
setMethod ("dbIsValid", "TeradataResult", function (dbObj, ...) {

	res <- dbObj

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbIsValid ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbIsValid ", res, "\n")))
	}

	return (! res@m_envMutable$bCleared)

}) # end method dbIsValid

setGeneric (name = "dbNextResult", def = function (res, ...) {
	standardGeneric ("dbNextResult")
})

#' Advances to the next result set.
#' `dbNextResult(res, ...)`
#' @param res A TeradataResult object
#' @return `TRUE` if there are more result sets; otherwise `FALSE`
#' @export
#' @rdname TeradataResult-class
setMethod ("dbNextResult", "TeradataResult", function (res, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter dbNextResult ", res, "\n"))
		on.exit (cat (paste0 ("< leave dbNextResult ", res, "\n")))
	}

	stopIfCleared (res)

	result <- .C ("rgoNextResult",
		uLog            = res@m_con@m_uLog,
		uRowsHandle     = res@m_envMutable$uRowsHandle,
		nErrorByteCount = 0L,
		uErrorPtr       = bit64::as.integer64 (0),
		pcAvail         = as.character (0),
		PACKAGE         = envGlobals$sDynLoadPackageName
	)

	if (result$nErrorByteCount > 0) {

		resultErr <- .C ("rgoFreeCharPointer",
			uLog            = res@m_con@m_uLog,
			nErrorByteCount = result$nErrorByteCount,
			uErrorPtr       = result$uErrorPtr,
			sErrorMsg       = rawToChar (as.raw (seq (65, 65, length = result$nErrorByteCount))), # prefill with 'A' characters
			PACKAGE         = envGlobals$sDynLoadPackageName
		)

		stop (resultErr$sErrorMsg)

	} # end if nErrorByteCount > 0

	bAvail <- result$pcAvail == "Y"
	if (bAvail) {
		obtainColumnMetaData (res)
		res@m_envMutable$uFetchedRowCount <- bit64::as.integer64 (0)
	}

	return (bAvail)

}) # end method dbNextResult

setGeneric (name = "setFetchedRowCount", def = function (res, u, ...) {
	standardGeneric ("setFetchedRowCount")
})

#' Sets the fetched row count for testing.
#' `setFetchedRowCount(res, ...)`
#' @param res A TeradataResult object
#' @param u The fetched row count
#' @return `TRUE` invisibly
#' @export
#' @rdname TeradataResult-class
setMethod ("setFetchedRowCount", "TeradataResult", function (res, u, ...) {

	if (res@m_con@m_bTraceLog) {
		cat (paste0 ("> enter setFetchedRowCount ", res, " u=", u, "\n"))
		on.exit (cat (paste0 ("< leave setFetchedRowCount ", res, " u=", u, "\n")))
	}

	res@m_envMutable$uFetchedRowCount <- u
	invisible (TRUE)

}) # end method setFetchedRowCount
